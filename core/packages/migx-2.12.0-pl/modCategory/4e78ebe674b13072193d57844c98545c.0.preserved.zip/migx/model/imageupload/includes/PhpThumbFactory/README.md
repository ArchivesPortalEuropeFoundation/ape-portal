# PHP Thumb

PHP Thumb is a light-weight image manipulation library 
aimed at thumbnail generation. It features the ability to 
resize by width, height, and percentage, create custom crops, 
or square crops from the center, and rotate the image. You can 
also easily add custom functionality to the library through plugins. 
It also features the ability to perform multiple manipulations per 
instance (also known as chaining), without the need to save and 
re-initialize the class with every manipulation.

More information and documentation is available at the project's 
homepage: [http://phpthumb.gxdlabs.com](http://phpthumb.gxdlabs.com)
