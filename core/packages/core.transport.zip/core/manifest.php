<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'de92571338c8c4e551eb60c3576dfe4d',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/9c31432ef1655c2259a0342413ab9be1.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => '3bb556462a4e7340a39762dd21e46bce',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/5ca554b881647296c954445df75057a2.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => 'df8bc24403c45c24bd4ca6545cc2cd82',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/c3b2aa43f6952d9ed8bdee1437c3cc1d.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '4f4ba55495576e038ad3da7755278424',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/568359a2c9d8cedcaa096975ceb85687.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '50aaa839d043e1900cc7afeceffb03f4',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/cbd43d5bda9a6cea5cd9cace663ddcfd.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '34cf58de580c3b112551dd5d2c5d0bc5',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/429fda6eda910fd22ce870ba120c8138.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'ce6d73d4571ab1725986f7f8c3845669',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/29c03821ced9186984dd08f7f1701971.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'fedd8315036e96821c23d34e2f466f44',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/297f9e265ea8a55467fc4c9e91d58694.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '82fa1a92bd5b20c7ab14d834e13893a8',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/aa9f4ea7dd95cd58e0fdb5c901ff0334.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'ff58c7408ee355568b844f49678eb5c2',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/9464ba2e4904d0274f6349cba5ead2c8.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'd056eb3aebc52ce912d1ab9cb6db8f6c',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/2cd5bc390d665bc29e6e3b57acbb3ac4.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'f20aaf604e7188181c329a6f39a15f5d',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/079c129970c2634f539658a2348f7afc.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '46ae8e8a680a4923db51fa4711e5ff77',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/eec3e5f8c29fa037575cc5b15e18b676.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e8e760de902182fb29b8e7eb71bc3d03',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/ea523ed1598af6ed0ab61f037f9a9bde.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da4801ad83792a765557bf469763c167',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/86ab2d1c6f4811377e5aa4cca16abf5c.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b7626d651be17d79e7aa6b8320186cbb',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/35819805126b2909586ae26745f733a2.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '706528ee577d80a2fba690e92b8d974d',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/d1720c3e1625c8ea15bcf2edc65b75a6.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '78abb67a69898d53fd0a7c12a165a771',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/fd65bc3af4d9ce2b184f39ec7b5ce5d7.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '35a62769be127ab89618c962fe94795f',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/b0f8c8ef74940d0feb43c1f76a750252.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0c018d4e423618f236fa7807e8001c54',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/14685d32c8bb16f98eb95ac26b9990a9.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9eafed2f1cf574fc24c36758055fb5b1',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/3e590727be4e1d167e3c358ff8f12501.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9b67dccb1ad4b90e330b7d139ed70689',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/655537ba72274967f82bf1aba1e06b8b.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7af3b1f8ef500c92ad750a16e79cad3d',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/e78dd6c6526d0c78dd2d6171321592da.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2f625ee5c7e007da38201839189b2ffb',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e325d6c2a6498fb0ef4576315d276a7c.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8a01f8975b584bcd744c767c3282ad0b',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/c9dc383e7a1dccf073e2bb968c70c323.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '45901c7c0d491824b5e4b052ccdab575',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6510d76cf8bcb8a072f2e197aa01e1a9.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b977c1cbf1ee723188ed1a4108440301',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/c2186314e628530031de808f8547c92d.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '75af60f5ae6edd36ff5d34e015a0d2eb',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/f38cd9460b6dfcf39cb53b5dccfb4a54.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '61ce6e3a14ff1efde1ee88cad8fd077f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/142b6b24148ef241126f62d02bf41246.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '078ae132cf8324f85ef5a29047a53215',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/bc026e8b2d9d1f41ca4ef4903d59b71b.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f9d1ee55bfb467f30a3da0b077589e58',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e94f43389919286b13a5e74d0ac82bfc.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1787235352c6b47722146a1c6d734256',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/0a8541de247df8c1f7cc6258fdd418a1.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4bf47bec4491d50541ee8fccc3b5fc7f',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/358386e8082e59f82f8cd9166ac64f0c.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fabc5de8b40ce5a8e9f2f5c20e082f4a',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/34b02cb70cbe3eb52741ed63a0412c93.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9fb2d4a12c4d5eabbb0a43e6dc934818',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/4110f4b19ab94cf20554bec3f8054b1c.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5162b4a8a72e9eb0949f9987c782f493',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/0f3a0a66d1dfcacbc52974e0cddfcc0f.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '98f5038a844692acf5a29fae815c3598',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/7e6f9fa9d0cb67bd2958fb62fe8c27ee.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2ab944501926f33b39f8b51587476961',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/825bc05d63863a5a5943d547cd56f3d6.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '35e78103a0e1e109a0bbe78297dc031d',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/650986dbc5644f30eef6e524a132c460.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9d1961cb843b1d255acc2ab7a8dc66b8',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/4962dc2d50cc7afc75807b85fca3e66d.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'df4e1f3a993defb346ccbb121278e1ed',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/c9970b6fecbb140da4b6fe2302c8100f.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5c1c12e224e8d0ada4710bdfe79825ce',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/f33770bbdf6c3c2cbdee6d82c889382d.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e62573e19672ef5b421a2cf984104d91',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/7186fdf02d55e472f961f10d26c891f9.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a7ed8888df72fa080faa6f90a8223e7f',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/b2154cb4e3600206f50f24c6052ccf99.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '84b9e648396ca68c51f05a42655c7b76',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/7c893c0e1dabbe09272ecbf67105f0fe.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7deb8486cf20afd24e0fa340862a5244',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/12c7d127ac8ce7031cce03890822b967.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '700a37d161a76eda335c70461125c491',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/7a2ebf0777763bb74f3a7c2a542e86f8.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ca49f7b3e2785191aa52a6afd23701e',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/2746ce2d255aba70ccb761521c4fcb06.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7ec9f8673800d177d07fd7344031a127',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/ed2e67c2b32c1d0eefd89168222fd2b9.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '514107c61baa73d28d5815317cbebed8',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/ef41359d4d0a0e43933ef7267067b880.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '26dd49beed91b1835ae56cbb1bc7f24d',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/cfb880bfbde11b6188b996a7f06b46a7.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '20a738dcaaefff4cad18064d18c240ae',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/f74a4f3f57cfef8c348c10eeac9c1813.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b3f2a23d0b005662bd99c47b6203c3ba',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/4df6bc5764a378b6a37a5d8e40be810f.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0a79dbbb47898e7f2aeeefcc8bc80a45',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/b24f5c0f52b7c659c6e375269cbc2afd.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b4ac39bd98eebf566d8dc7da0d6e2705',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/a3d5e32ee58dda373c2fcc68987f477f.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12cae40666762c21a435956f90fadb50',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/bc83bd2546bfc5ab6dbb6a9871b32378.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '43f70b27a90512b9dd1e8fff8c8b8ace',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/bf50b03cce1f07c1ac8d1f9866a40755.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a37048b5963776e3bf5c0f40f157ed4a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/de240f75e6f2f9ac5169149d58fc7fbd.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '13a1cc1181c6ceef9f1aceafb512a9d1',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/ea071c3d66011bdf184f957c8e6d2d7c.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb9b13a2003d64c9f573ec68ea4f6fe5',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/de3f853a741697288042e49dd07a6fe9.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '86c98851984d27a44a23306ae684e5ca',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/5944a78b08dc40fb0e7a5d57ceaa0311.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fda16eb8ad516b45d2ea9504d509c98e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/8a66410e18e0918a0b960af5cb942a85.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'de9a118fff25e676e946dffc6a66cdd7',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/6d039ac2e2f55c796d01b23ac17ea8ee.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8ced9929af9e20ea65b173d3522c785e',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/619a7ac39dd66fdc2c1f3e7ee9e6bf65.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a3bc7113721b1d4a1d3a9d9144a20e98',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/1419206badc2c483f6982ef34c391681.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bdacdf83288927ec822acff0e5dcae03',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/1981f63e284b0081eeae0ac5200393fb.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4b280d5ce8d0722532b9a6022de2f809',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/9f884638e9fb9416353a2c62be3302b9.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4ff81ee6075242be552cc5101c337c13',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/421fec507028736b22b435eaf6a69309.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '08a07a4fc2ed2bd662af1d14aca022a3',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/666b61293ccf9e09fe4896c2f96fb6a7.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fea81890dbb00d7e597614f08fd6c004',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/837e90f1a103624840554bfae10ba0af.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '59e2eda95a25b805859331ba76d7770d',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/ac431fa90e7ac4001d78d64082730f8f.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f935f19084f43aead6833d3942911967',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/d0adb73f006a8d8321f14d792f5f0ea3.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bfea4350a6ece06192cb9359747bf991',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/961678ef0948ddaaa39a108ea82c9464.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '42ab38243296b50627f03a012198c357',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/f8cf237fbe986fc1bfc36e982889d907.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8d79bc22f79bf3bdce0ef0bfafb8fe9b',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/638c4cbcab67259c63d8e6210209c005.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '87fbdcec35f07728f23cbe8a3a66be96',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/5ad490f7f7409ad2ba50aad81793699f.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'db4e99864bc5bcb5cf68c7c24521ca21',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/5fc8136142d2b3885eb5c80550d09440.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'adac534b1db86394a01693a3b2c586be',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/fa94984b1ab06ad413982e577a106c97.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28cb6da3dab200d7d35e4b3d65088312',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/8ba8fdb3707aff04862570e6a5d8fc41.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fb888d404176e648f8f85b1bbfaf8069',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/ce05e2ed0e23d769575903ed1bcc6e52.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '33225bb3755f4ec467426051af66f44d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/0261680305ea7331a7e6ba89e2f37749.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c91a570e922982726f6dc1a15c4ede95',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/95b43fd8a6515cb7d3d7a4ac354cee1c.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4d822dc70cc7538dc5f55e933cf90e72',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/0c479ace956b22f48d5e5cfaf19baca5.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6d9cc05f3e35fea099d47148962baac8',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/a3b148bae241e95c56f3abb07154c529.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ee24a906a07e371d8479b563450b84c6',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/bf7bb60109df92b097104146449f78ac.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a918b2a1c48d8cd08f1b9021c42e52f0',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/fb4dba4a105dce6fc966c860e022664a.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4f0150f83013377ecd6dee34910eed22',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/0acc79ce90978d318b906e0680cde203.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fc23b9096aedc5d0ad14dd53abfd4744',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/dbb9ee7c89d9ec61121e8e5dd7639741.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '93dd426b6855d0101c7de6583270c7b0',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/f08751362319d272028eec4341a1f071.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c4893e4c657d1da12a02d84afab2ef4a',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/9900a48000932d4cba101aa154074f20.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '096a8cfc862ecdd955adc8479c849f4c',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/ae018ab61d8ce39fffd176edaf9fd5a2.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3f57a6210bd8606c8e8f1a1d5525c2c1',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/e793549af9efd58f8dbd06b31043a0f8.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '59225fc0bcd7c261d1221e13a8167c6c',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/8cce5c69135f954ab95f7625fddf79e3.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9382c081fe4446c625e1de4ebf56a00e',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/eaa3e88ac9635e2633a44fe3c3a90e53.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ccbaf914eba42da6590b75d2dcf12b3c',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/6c1b785ab594798fcedf094686b96660.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '93f39c4f9bf374c91314a90e311776f6',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/7dbd8e1c5d74d30cedebee29bb3ab951.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b6eb0a1104b6b0ad511c263039196563',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/f30897b50601ed0aea38c67def8e93e9.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3fbc00f319fabb930a15eab135f195d3',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/e46117e5180ce6eb47d3bc6a944a9e21.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0d9af5394160063718e9b24377f400b5',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/500482d48859d922e90da4799bc49f89.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6fc6878766b1dc59755f794a1a31e58f',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/31248642c21c8ebc83943eaa45d05749.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3cc4d198efca5a1a11158b5b2fbf1e64',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/42daf92f713ca0cf52be4cecbd54c707.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5e7f5bf118ebe3d15b60378e539458ae',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/40424adac52b55f4317807ab270c2d91.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1cafebf60557baa094e05ac1eb4535d8',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/4e687d025286b2360fe1c9d5df9fe413.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '64987950184ec58baca8240a84cf887e',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/1f0988b15d24497b657fc1fe1c6440c3.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '26437c758d4a6e9873cecfbff09c990c',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/78598b8ab2cba76ddcd71a7089400bf6.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4b7aced4f8189c000fe3a1b2963443ab',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6a7af50716b7bb5a91db8babc76b9672.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '297dfb9e94572aee5dc7de31d7238356',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/d622dc5567c9a15cb6b1e736176a8fac.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '56a28f9f37378e8ae755f27076165082',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/c492bff476f2ce2ea87d1fe729fd738f.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f053d26629891e446bb7aaba1b44501c',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/4e9acded2c14650f53d69eccbb66d22b.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cd01fd13d543548fabe902241ed4759e',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/da59668100476ccf238d3e515ed609ed.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1786f444799048e5da5b2fcb429a609d',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/5d04518b55e8bdfc6d1e0204f6a7f3ac.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '21872422e5d4db125199645f9bcadec1',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/b8923d0a7e6230ae080c44e205d2e955.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bfb3f96177717cdde81db2e14acdf97a',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/11f124438c4e1e4663cd2e4964881da7.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '299efce5aa1191aa359c7adc7bbca1cd',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/bf823247c0f776c063cde763603df092.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fbc7803005edb373966d05b67b71cd91',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/f3b49da44818a835cbadd2f143c4405f.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cb5e3095ebf3982d9730c434526eae11',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/a83089e45a7d697ff2560148f1499ce2.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '261179062cf8cb9a14bd8cd34c427051',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/397a2b8e3f1a1d58d23dae260ce9c640.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f2706a3daf0caafb1c61960c4db5cd0',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/c1180e07adb14860c6c14fa7d2424a74.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e236761feb9c9a05f5dd8136f819a935',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/caa4bcda1c549b39d018207d5c6f7a74.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b36fa9308f6a1e291a5e7b3ee8c90148',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/947c44f911a33fb4cc95fdb7958cac79.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b8f4aa2c56aff5b635c4bc589f636f34',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/81d3a56ed8ea08de7b9b861482bfb38d.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a5a3d28bb10ae5b12865bfd2701711e4',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/1ac13fdfe589dfb88febf7b7f5e2cd96.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2d2f1797d5047d36a6ece02ebfc43ebb',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/43b74a0487116c7fcfe01d695944f43d.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f5f21fafa161be5b7838d189fa702959',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/9d597e00039ad0543ceca779d765eb7f.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1d0ec525bc2c1e6515424522ef1324c3',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/3ca8bb9dadd7bf24fe9ef836607099d2.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd6e8629c4b0665bd1c781d327f994d8f',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/6d2d622174c789d22a112630eef6e819.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '148c9062f5c6d5f2994e189441de1ee6',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/a4112b8fc177efe39d7951bfb48b62d7.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2f563136f18372a66c9152d4bc37ab33',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/1bc2c7ad1d907b6c65f7c0e1706ebe7c.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f12f6791b3a706d4613cc3b1480c9f71',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/16e739d10bd7060d93e3d0005adb92e0.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '70207503d8f2b75e660038d565739960',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/7f58dfe0fca36322c04f61eaadb98d1a.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0bd85b888467998518f3ee206a6ff7eb',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/8e48089fb540e31fc518909a6aadafcb.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '03ae0fc17a21d592caa9727393424e4a',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/06effdd7c7d782951fb934a0f0246174.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8439811af1053f86d0f315f78727b3da',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/71b4dee518b49e7f3814f036b86983e8.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12804a5f10bd8e7c5f227a446726651f',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/758f0a74ee8f13d0e9549c0bf7dff0d5.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b3007a2805fd0b7b0ae4a664065b03f',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/237301e74819a431fd3e2fdf5fbbf0ac.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1cacaeb28f671d40ef2f8b2dbb2227c7',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/40641aeb05e3abc0c90e97d932aca26d.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7a31b1ca4fc537a36cb94b2f43830b0c',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/e7fc588804a1ce710dd55a00cebd7fc3.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '97b6f83f42babbb1dd6c42dd596cc139',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/20c200ac63b2443f29bf62df0b9a14a5.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '27ced652a63bd8ab2576fcf9dc1be994',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/58bd5c759cf048e7bc2550fc57acca14.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '79e0acc5a6846066b7b18ca525cfdd91',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/f41c7c916484e13b1435f5433c3cdc2a.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f3bc2d4ddbd13d17b10d2d50d2339c1',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/f7c90cc1d49df440955813c778e804d7.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7ed16a7bdcfc26f2dd9c0c7e88e5c9fa',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/85de58e9bd62164fd91ccd4a5d2e2ad7.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0f0859500c425da73251ad73daa1d181',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/98369cd7efe4dcf7a71a02d5feef6db5.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'efa70f9f45c0216f113bc465959feab8',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/276b196e193aa2e77884120c9c8a6c8a.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dad605cb3396b5fb20a4fc4d443e7edf',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5e15831e4231c322770de83fff6ba4f5.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9c2342700bcc2d54b13a5b0bd5be655c',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/85156c493ac804a1cda10275e9039d5c.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4b7da106a5ac3859029fd21215f39914',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/1c4e70103b8f785d9bafc6ce87461446.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '14e9a40a52d9122b2daeacfa55b4c084',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/a9a87d5ae1e705dbac9c9288c9f9a9c2.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd6c033ddf5f1e0daa00276626a6cecc4',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/1fde57bfd76412ab93e0fb1f222584c0.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '91deaea9e814165ce7a73dea4cccab9c',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/07dbd8fe17fa419ec4fdac2b193d2ee3.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a0f11693356c33f710151cfeb6f15ac1',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/3c6efeae3b525eec6234267087b9add8.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3c92f229ba8a42e7b342c71a1dbbcb79',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/dffda2e88e10777bca39f538b879118b.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9a097e1d4b33b9693e2a052916da5ac8',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/9419a86448a779a167f90d936dcd1192.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f17e37788a483e896489abecbd64c962',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/a8d01fb5060ed913bf59d139fcfa6237.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '89e578c7a383e6628232dfd387538529',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/2502b3413fc9d42ba2d1c74f8e2c2277.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8f8beb7b5084d92de0f00fd8564dd7cb',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/93d68efdf28b278275aad9196ed20d61.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'af5dc2027c79aa27be09389723055e34',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/96f17ff2cee55d151721de746584c4f5.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '820e942a2331140f08a24384ebbc15ec',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/9312952742e0a8c8ecda9b5d18478759.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'af2ffbba5725edf9a25af6faa28a7341',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/7fbe32fa9e1500fef738d354adc451e9.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '06bc117f2c0dad23820afd2c57c0f4b5',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/ebb3e686c3d48e969f4f3b6ebad45e47.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '10862d2c70e1ef29a77ae99a6a3bbc1c',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/53c78e2667ded64ee389f3e4fa4a936f.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '219a3ecba9b6db057b0f1938b25d6d53',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/cbc0f31fc60bb1d83d573d1d10d861f3.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bdbfe7224e688e1a0097754d9875d7c7',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/7762c9c4f636146aa613ab4128712530.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9ef6c88b68fa8a9821eedf02760d213b',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/caad78e8a8dd72227cd635d14b77b6a5.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9f4f7afad5a780ce4738df2dfcd557d2',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/b6a380a2e7b90dba83580db8180472dc.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bfa41ba2b83fe3a98c4164b7eaa351c4',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/532b8ed9971646e85ec7912990ef32d3.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2afbb4126615524e3a6fd0357d8b92b2',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/b47d29f919dbfa6146b11e45c3723b9b.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '62427fc4d9f529e3b86229e3a8681068',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/49d1dcc7a884330d643f558deeea6f64.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f8c86ec53d80d4a802d50dba3780caf3',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/0e931791f11049f8108824f865aa5bfd.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '301bd04e5cdf33bd7ae526a1fbda7c60',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/8f44ab9e17041261ce47e2032c3dca3f.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5ec7ff26bed2a3266c9ace6d21e48d6a',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/23fbc3c3cf64feaaad651c2f19185584.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'effe4350d90290e5488a0872b032d4f7',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/82e9a794893b8d07befee2759c783bc6.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '57c3240bc57ca31490e2ed876f5ce829',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/770682a7a9bd9c03bbf09d2c0a1c59ec.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0c76c60f92bf246469435a1955fb02e2',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/ac32dd770e2cb68534b54d8b4350a31a.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '55d46e6c930278f92ee3783b893f31e7',
      'native_key' => 'OnContextInit',
      'filename' => 'MODX/Revolution/modEvent/325c27e2637e79a58e13d066dc7c4cb5.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e673ba00c864b54ac7bab7cadc4e429e',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/43c9de0c49767bf81cff18660fd50c4a.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '25d0e120801c2ffb87cef57ad7ce5f75',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7b8aa2b8604f8b57369e35f69efd0881.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '71f4b51da5a5f14730c0e8b12302820d',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/12d2daf4e6d7d8ed46038b8fbc0a5af0.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '096eea2e874109404c933f36a2649bbb',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0c1b142e242bd5d265d00457224b2903.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fa47b97d0f084b05fcd8ee5743145bd2',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/9a44d248f9a957f182affe74cb287e55.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9aa86e6ac22147990b07384af63718c7',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/af4f73ee09810b35cdcda03397415426.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4c09e4dc48b25e4e9f96ff40c26ee204',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/e2e5bb56f1fde3a0a622ddee1d352d3d.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1411e476cc04b1e34593508471c41139',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/fa5c5ec1ea2a83a2ab40adf987088fa4.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '83b479aa0dfc8c9c658ba7b3e10c5699',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/918b21c789e90020f9fedd18865b18a0.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8d26a1bb6be3f1a8776186f327206310',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/96dc118ac2e32546d7bef52e4893dada.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '47f3d167b14160e944cf5988e1bb4635',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ce0cda1b52874eb56896dfb8d1c56703.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6092a2077dcf98da56c330f15ad758eb',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/425bd3631b0b4b8559d29580ecc9c4cf.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12b7da344bc97a305b3a2f4e153674e7',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/0188816286e497980c59032d2e73b3a3.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '93be809148f6451ef68dfeb379e131b4',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/a08773500596c3e95c781cd187f8a271.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd38961ddeff46645b418142115699a0a',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/44c8556558703a2d422fcbdc06bc61d1.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '43f126afdb5e37c2bc2a6482542298ed',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/8e66d9b52f533c7863156dbac8bfba9d.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0b15c14acf820f4f2f1ea4d07ac3edfe',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/094caed4b79861b814bf39b4b53f62a3.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5134afca7de08b18fa21a3ad7396d850',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/2745156f784688b1e79bdf9affe5ca2a.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b943c3297e0468ccd04d5368b9f36f15',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/d03a142561e348538424bdb5dcb972a8.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bfe95d5f3f17187acbc600d852745ed8',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/7f57770ed3c43bf36984af2707eba12f.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8d0483d9d62ee01b9a0b26820691c1d9',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/8946a8a0ef9bb7fae78e16365ed7e8b1.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fb95d5c044c410ae049f91e54facdcbf',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/11560b4aa0392fcf589df0b6f7f1daf0.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bbf0b60f4fc4144c876af59b1dd1b502',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/bf366a2def36f9648fa4586f86567e04.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '85332a7551eedbbc1878ab113546294d',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6dd9e3dd0a498b5f38c7482d91ac11d9.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da0847c4cd1a16033410e1456e366de5',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/c97c0d6841cd208928146eea825684f8.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3fc4f434992cb2e7a69cf8fd26b6ec54',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/211d4d811aca0a39b9b516e70b090cba.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '94dd91a3ed804ff475ab25b8ace33ef2',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/5ebc1300beaec7175bb94f1fa13916fe.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bcf5ce9001dbafd6370d24c02ce98162',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/99001609ca91003079d9ad6984b81f53.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ee39feea1236a7a0c2b7c8b15e3c392',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/eae7dcb1baf57fd9c7e8e692c7fbf234.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dab07bbbf29bab10b2af4d83a8f7c14d',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/dc69291f568bd8235e3e2adced357d05.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '358f940d4eababe34d2a9361cfbeac4a',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/cee38a731b2efe6ddc7f2c20eb25556b.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ce23270044cf42f4fbc4273c7410bbe',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/bc64591c6080d584c1f088507cb1086b.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9bfa83618a2bd5cdb84cbcbe8c17bb21',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/b548d1e1181fda5673979d59c67401ec.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3eda44ed14a2b1f7b2c09ce2ec0494a9',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/bce9f0bec508432322813a314b98b73b.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72d42b3a76d676549628016027468447',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/b4e565bcf99c3e365513db9dd415a285.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8e85c4f30128e149c4a69d9c4b2dbdc4',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/838fd5cc128e585b6596b3485b13bf97.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5459a754f24c11e878ecfe740428c4f1',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/ae3dac229e43a4d47663deb4ba67b86c.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8dd2cfd6153c2c2dbeda327cab3d229f',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/8aa57844caadf078f9f8cae03499e6bb.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '274257da41d84c0d7163f642e1a8f343',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/b80b5d25adddda4934952a2a5c38408a.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37c9d2fa5145441fc2e9e5f18b7d56ff',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/e576881a1796b02a48fcd16cd9a20870.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bc5ef310128ef0d102a6f42f87b76c70',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/a1da88180a18c4ae07f8d28a14b29053.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cd92807ee3f6b8bfb7349f61f06d3065',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/5cff2a1445ebd8b8e9f884a7d2f37f6f.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a12757812b2cb90bf565f0f3968de53',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/4bac47031b2147766fb015967059f8f0.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a70125802c6dc5f3c23bf1f38d2f5cf3',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/7e6dbaf46c02b5536d8eca23cfa50009.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3b9f32e56b8ed42ace097173ae764968',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/d1a34206fdd23230a611debcfc61388c.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5849b50231701998dd93bfcbfcf4ada',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/c50be83f21f70fcf1adc0a998b65109c.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1af533e945542660c5b0c9870113edce',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/84c73e19041dc5752dd733eff669477a.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'efc210990f355568eb7f920f328626b8',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/baa03355ea323e01e3d086b7aa7fcc88.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b83d3fd675d072567a19568d16dcc24b',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/1575750a1cde1ea0821f264659f1730f.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7fd0427cc0d29f6fd179e80a174b9dc5',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/9d16b49525306624b6f65ad299f3ae17.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5952c3d509df5b33f5558e0a287be45',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/b063fb2937446c176e9da7fb2fb0c472.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cb3289b34b546c1f63bb89c3dd1243c1',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/22c58e5758f3a3d29ddaa49aa9064845.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1ea088e1af645da8fd7b663f3957f618',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/18697085aac184dbcca7782a546b4bef.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0a6fd587ffe30be7a030210517fb4b9',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/d3ea6e48000db4926962d2bd267cee25.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '93e038cbad959c5e69db5a50b26cf3a1',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/918b97ce600b5196f2f338806233d3a6.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5eb17c4999edd0c5da1dea4a4e6f5b19',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/f5ab6adca8540820b5b9da72ab1b509d.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1594881256a5df4b1a1be9e87d51d069',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/4b67c73d0daa065debe007b87dff7964.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '26ff3e5aa718a5b9c45135d2f5931bab',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/64b8a12563a0940137560c439275f566.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5527c1f5f1aaebee5712d3faa92b0f86',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/dfe929c9a9f9951d06296400525c14fa.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1ee0f4584d8c61df376af5bb8e37c2fe',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/e3c8eaddbbcde0bd8aa781ffa0f41dd6.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff8029d79a272e350460bafd5218f657',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/f819bbd9c685d6a58c6b45e873347b92.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6e262cc634c7da4979e7cf7441fb33a3',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/bb678b5378161545b3a0e7d5cd9415b6.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd42d7ef16ac840931d251966ed77c366',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/0d3278303db4fef33762ec554ca9d3cd.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1908e30a4f21b06c036ee432b842eda6',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/c61c4059149801087ef32e9a58054349.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5329fa0964bcaeb4412976d2afa4526c',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/44bcca23c927304159b65aa092157538.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '867a889f05db58c694e9229b8660b6cc',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/536cfc603e27023941855f284680ccb8.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '00043e67a4a89ca992f4ea88aea20ec5',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/2495741657f52fcce61055a3031741fd.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fabfaf838deff0035a37ed0346bb7249',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/40c9ba7b6cf57f978161a9fee40c2c58.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '98cbfc0ce6cb4208058c0af97aa7ecf0',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/dd19117abb586233b4416f628a2891c0.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7a351fcc3324eeffbd1cb3b1a26c8bf6',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/23d066602c62e711988db8ceb0a8162a.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66d1b4c6173b5be3f3e0514eea369426',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/e4ca03105de108c4da336b5f63a440b2.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7b2082e725a83095f00c91fef0ff3d31',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/80252af5fad366bae2ee8fc507e2eb21.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6e73af7006063aa665455fdd127d7c55',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/fddc026d774390e8745b4a290c44cec0.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8c8ce27bd9da42f4efa7601e70c9106c',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/9216f65ac3c7c8aa2ee6269883892702.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cfbc5aaee99a3890f3e7dc3d731ca6d5',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/b676c70430cf6748c3a120aaabd68a60.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '29c7c3530c0c404a2af22345f6aa66d7',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/05b8e7625fb85b47701fa79039bdcc82.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8185a4b8b93c1ca9fa773c9be9690eef',
      'native_key' => 'photo_profile_source',
      'filename' => 'MODX/Revolution/modSystemSetting/91797eb330b925c4e23348940ca2da76.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dd726e191c1ad5f64447595cc5924e10',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/c665d486cc4def53f48873dab32bdfbb.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f64e654a891daafe2a70687b1f4bd1d1',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/fac20ec73e846ce482de9d4e97146a9f.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c69ffe08f69d83cd229d67190114c5a2',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/347d18ed2780126501d6fe0bb83b5099.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ba30bad34b4393ef037e45a5eec1965a',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/acce7ba6267236df4b51a24bcc86e4d7.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '95cb4f93a1c4779c75976d8b46559bf1',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/a3016209dbb661f1bb8e38c40cdf153e.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a83bf61c496bb46d8c9d533e74c00173',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/aa6e9026a5d21ee8e369d84e80f4804c.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8316bd795f9175873cea3cd7b051fa02',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/e528a75fa9fd7190a4a702500448e384.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '55bf1506effe8106002a2a1e1498c115',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/47fa5d4ca825807b05ce77d9321d6ee4.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '49fc201c84eee3b8ad21cf5f7d57a206',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/0b82f925cb25b5d0e2e9605de730ee44.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dafeefe74ee212b028f22ed7fe5f74bb',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/63179785f609f5131804c5de25ab13a1.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '69d9641c2bf62dc7a9a4cffe3efda150',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/90ca81302a1487e261523557bdda4e6d.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f78d865efd81bfb943a3d2820d8bf50',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/0d3407f9b6a01d682162eeab8883fe39.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '68df521a5f639250548c473048f5385f',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/c375ec4a95a6af7f470720dd32a8f482.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0d983cbaa1398930d883d444147fff65',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/04b92ae6c1802dca23e83dfc6c427457.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1d85663fd8e7166e6940b17ac7f512da',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/7dfdac32675a844257cde1fde61e065a.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c83494c238b1fdc898ff3ee1be65b0c',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/9ce37a5db190668de7b25966f1c52753.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ea23abf279788ea3caf958d3777435bb',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/24ac20f0be49b574d4c70413cca3e8b6.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0d23bf2937f89176bbaa89414ea9fd3a',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/b07307bdda5c48c549ae2f315841df86.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '254da8ab9ac7f8e66e274a2e6256c554',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/70837a87e3df2ebc4b00241b538a2c67.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b3ae759a685eaf17d52fca4b16a632a5',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/22a0f993f397f281449a36b718db1fe2.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '33e7cec53f870c1e5ac705977f9ff21d',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/90e1d893ba605d895f01e8a69f7c20cb.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f58fd2127f32ae7f4603a80ebc2b5f31',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/df3651c24d8bf348a3d6ed489ad61810.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7a82a368fd99be2a2c38be4ed0485da3',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/3c005abfd737b135acf0a80b63e54cca.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dcef4c5cc466f5dd47db71b70be7b8a3',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/84592599d6d9745abc0fc25fd8a1328a.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd03dd30c14ee8123b59dfc6476e946e5',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/39e5e748a1b927678079f853436168f3.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0103de5deb635fc9375df30888717563',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/a23d3bd699be754cde7ccf69372fb9c5.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '805cb22b6bc4206dd1cfa0cb3b9c57e8',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/b490db6c032eb6ceb101e90f937919f0.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5a454c32ddd21b45e2411930824e8e77',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/e3bc322abb5d018b603a957dc8409c11.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0f3a8f1f188f7b11f954e50dbcbf4a15',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/d46f2c6be62fa68cfef73457e11b004e.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f774851d8eaf9cc2d275a71ff9ac2fd',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/0762a6baaac1bee16e8f24e8feefdb9b.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6b226924c63f6a2d5a136e185d7300f9',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/c74b66ff2dc5a6dc27521275e284679b.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '17d160d62398b1ab86a56a3e07bd6f3e',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/b890328a48e49c13869b092da94c8ad3.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd888c94a84a9201f2fcbcb93408b1132',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/50b03c1cc300e0aa1454a55f8a751eab.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62b5e605e659da40c50b16453cfb305d',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/c41ddc3349601c7cd9c367e90903a2b4.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '664f43470b456e63989ec2ffb36f867e',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/23f7edb20c92e08f03d1db07a4cd2cfa.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '524b30c4cbf30005734e561a440833d0',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/f831abb1db1651844a545aac813499d5.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62151c13f6d637380a4cdb1379b7c4cd',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/0add142fd8ace01de1f920b7ed0006ac.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd1ddeccc9af8a092e5dbf56576f92221',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/c25e19ac932569b5b21b8a2c457ed569.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0fdf383a67b19b81ff3f9d86d94a3ccf',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/6d6327f6c95d332766fdc1c6c30324a1.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31ef25ed8d090ee7216ac390ce007d2b',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/4e63e19aef6caa2f361f9c848db95ccf.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '02f84e2bdf1c7dd019c4cd602ac2bd74',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/c4db880b6dd408e3bca2c9de9a65695f.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a985e04d6bfc536362cc5538345e7b7c',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/0e9dfc1314f9d6a216cce4b440267046.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91ac544c133c668e04c4f9e630dc1c50',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/c7a4941536f3ac0e375e549ee14d52ab.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c6e131b8a52a94d905a03c565aed5131',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/d027dd30ae96a6b6c5a79a36c036bf68.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'af323f2d853a923e746ef5f5882ab6d0',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/08fdbb672260366c704e018529724a07.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '44e18b5acf5521a9a2d3b510d1ed3256',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/ccb8e7cf8a26f6045d949f2c2568c4fb.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31659cc0e177cd4f1f948619f3846a18',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/edf729c9ee58ab6b60b800fcaf113add.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6156db5d9221bd93acd51ca4997af606',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/8558dccd7fa118fb24abec2cb043707c.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a59366205828181fca4938574d2ad3a',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/9260e8f94c8e6ed660cf5f23127adefc.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a459c17f695a3d1b6cd7517d6c3ba70',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/2c976973181fe25ccebdc9a78628957a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2dc5bd3feb7ab51e6feb39d49971f6a0',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/4cfa23df6497e96ba20745e9cb8f8aec.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff1efbd2c3d766166247fa46a9f3048a',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/b6291ccd3e06f063d2b6b24156b89649.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f4f6c92464ed13141a1ef5b086322a78',
      'native_key' => 'mail_dkim_selector',
      'filename' => 'MODX/Revolution/modSystemSetting/b2f44a1b97ff4800994157afde6b2e0d.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '964f20dd5482873a01c4e5a619b2d8b7',
      'native_key' => 'mail_dkim_identity',
      'filename' => 'MODX/Revolution/modSystemSetting/b0f1b866d9bc2080391881679e54a1b8.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cf6d5637e82353a0e472e01804741ee7',
      'native_key' => 'mail_dkim_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/de0d2776154bad0764d8726c0f52d8a4.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'efd0bbf939a726ed9fb7e4a4d8ce6e93',
      'native_key' => 'mail_dkim_privatekeyfile',
      'filename' => 'MODX/Revolution/modSystemSetting/08c6997aad46c72bc72701768c496735.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fee6a5484d94f6c169c46aa9e3b6be2b',
      'native_key' => 'mail_dkim_privatekeystring',
      'filename' => 'MODX/Revolution/modSystemSetting/587a3748ec2dbcffeb1b50fe4a72d965.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e5537db56068b0a19f17ca6c1741de3a',
      'native_key' => 'mail_dkim_passphrase',
      'filename' => 'MODX/Revolution/modSystemSetting/6d8750504f47be08d50e14124fc0fc4f.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '81023d10bf299ad0c89b425fe5617d19',
      'native_key' => 'mail_inlinestyle_inline',
      'filename' => 'MODX/Revolution/modSystemSetting/105d24f367bff4cf9ff2ff39b9f1b45f.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '32e7708bee8a72b04d46891d1efaf52b',
      'native_key' => 'mail_inlinestyle_remove_style_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/86905534b59103d11e06539c8aaf165c.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5233180767f9f394d0e6ccebb3ec7fc3',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/918599bcacebf37e013b61cc6485948e.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee9ff28b4aa82b402e435e9ea1728a33',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/6106b74687c1a12aa7de76a18bd4eb6a.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0726ccb9ff0115d30dcacbd936d4fd7e',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/e487e39137e7e29f87bd5c07acba4bbb.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0cc5b6abe50b200e1ebeed400dbd2074',
      'native_key' => 'manager_datetime_separator',
      'filename' => 'MODX/Revolution/modSystemSetting/6f05ae7a8e6f22e5b04177da58f98f83.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ddf32cc5750c9987d01d05cb8b8827ce',
      'native_key' => 'manager_datetime_empty_value',
      'filename' => 'MODX/Revolution/modSystemSetting/73206d893c4b7d85d9d1897875a9b4a7.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6745716ec7daa389a587d06cfa7c9f4d',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/68f8e53c63de573341555237a099b622.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72c19c135023a13cfcd445908c0817c4',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/ad8e8ee6c6574a46748a9cd10a7f5e5b.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e67fd69480f753ee12cbd64cc3124ad',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/82bb53aa53c31dfa62a88038d482446a.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '63aa6b71855da8c7d11c37ec77d15b6f',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/eb8f94775e56b6eefd53f148bf10cf1a.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a582015e6964d1ee0f90edb166e30e4',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/ca83e508d62a2c4817cf87bfdc1c95f6.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4d3838ded59d8764097153ebe58b1252',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/3847ff0bed04a44280da4f29390ef0df.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f18621314118b727f26e0279b31f373c',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/b46020e6f392b275b17036485af34b2a.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '382ae546899016c98588a309cf85407b',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/7487a400fe61d69552458d362ea90bc6.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5224451b6f83e2599f7a4421aeee64b4',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/d3f32eca6f9b9edce66462381305ce4b.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4090d63a86e8fa63953b30186f98e251',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/38737c8f6cb1a02565c61ad76cf36c95.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ae15484ffc2e513c1aa30e40813ad801',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/e70dd3169b4a3c787c8a3ed047e58657.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '217a0f8d964a643beb8f8ac712129752',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/cbce9aab2b27911c66c2a8cb7707595a.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'deab1f178a03fd22b607d639b1251694',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/5b546f1b3ab731354926e6c9b9707f66.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75c72142d7d9dcc0e36a91d2454f7393',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/f64ef42d5fb19cd81dd452dfbc5a1c96.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a5ded150cb602e4d0463d7b720ee183',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/b439cb6027c17f9e80e61cc374597c67.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '822f5606eac2cd5bd635de6125a00170',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/bb2e133695031432ace0a1fae16a50dd.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72789b9f259c6bf6e81337af2b2e9e93',
      'native_key' => 'package_installer_at_top',
      'filename' => 'MODX/Revolution/modSystemSetting/0a794c20a59e5cc38f38ac071a6414df.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1027cb7610b4ade73753617c71e030b1',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/882526a85812a6ecda527adbc236308f.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '27d78d68d568b27ec20898a8646b2481',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/368b44b406e412f88eb4ce9b840b0c32.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c04710b6f81a5e17e5db71e1049da10a',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/2e4870f40f1d0ab66cdde7622fb32773.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bd9a720e12c89f3f2e68c09baa528247',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/94f56c8d03bc6caa7be21ac67bb52207.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '652235552ad099e568b490ed93e4a590',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/190952ea90600cd5bb7311840df026c0.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '40bb2dcdf2da4c65d420a401c0908953',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/d0a7f79903fd50b2ff69ce83a1704978.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '28c2da16f6ffbe8a848cfaa5c82aea78',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/904d0c6015c9b6c437e9af45128ec19c.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '69f7d86da3013fc546e7fe1d120a8930',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/fba5924356de906fe71fa8dcf58403a4.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a04cbd80fa065d86d4e2384f90bd5def',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/56d2e298e7123fd98a40e2b967902d91.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da31aff3b37382029db8dc128fef1a4a',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/45dd343d865134ffa74b868f07839fad.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '88bd131019766cc9c1f73ffaebadd50b',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/6fb6683f81ab8ee760b05e162bd9f809.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '69e4996b0c713dd0b1ff6b0f4db9e22a',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/02c41dc2e785b4ddcde439b0816c13ff.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82950316df4e40e9acacc962efe95024',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/024590402d94cd60297c54ec25204287.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3175a34396bc76621abb3181821e1900',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/a7ffad37a5b5d9fbd6841b00b456934a.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eb19493ebbee4e677a13999d2d5416c1',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/de6555a99d1b3734db0ed97552f8dae6.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '739d5e0b248f94ca75ae5355c4540f1d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/3fbb6c3f86b88104ed254e94f920eea4.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7fbfa48f24340600138faf37ea126e83',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/2590fcdee58f7f6768f63bd438060a8c.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d5ea653ca30b4202ab8c6ca6ed7d260',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/81fbef65e3ab1475827f5e2ebe18704f.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '61a7e2da96b7363c8fdc0a88d71ddee4',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/f4b57ac6d06938e125a2da8aaf049e2e.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '716ed4f9ea1cf763d306c93622b266b2',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/28efbf106d2c17f7bc3b8a202a3c1b0a.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66cfa5f3af6601d51aa94f38172a7eb7',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/045f9471e3e0d2501dcdb0d7ed247436.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e35b5c03ba5d1cb982e576f77d14690',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/07616617ae40dca6c86f9b932f8e0b0f.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9f84dbbd73fd2f4da6a03e3be298a0af',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/d792e812d496b994729b43f05149d7ce.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1079d42862c1a69e68541ef6f9d2ec4c',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/d604fd7876ef197dc530100cb55e567b.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f608d51cd5aad2d728a8ba6407a32ff8',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/1c94d4a506d99f9af82ca64921462403.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08ac79629448d0d6a580ea6ad33dc0d3',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/57faffa1c932eb8385bda52cd5fd2046.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee6d1d5265fb16cdfefb2af39edd518e',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/48501971a912bb4579b9185de114704b.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'afbd822cd26f27f18b3048efbcf57212',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/cd15bda8d40ef22ac7955486371ff034.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60e09b4eee1076883efeb58788750036',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/433b9354b47e295f2cbdc66bbdeead33.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f37bf3f4fbc291da5d9a1ba4e5da2ae4',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/b23be29299f15801be199310a45f5c36.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6b51d36ecd299ccee9fa44769cfc5fa3',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/ca7d6c715f9b7a0b882e1b056c168d11.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22a1a58ee573591631ca42128f311330',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/9d93e5843573ca8fb3a6c56562426596.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1da89313466a61df6c400d366bdeab37',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/70c8664439b5a79921d7ede9132c6321.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0b9c6754dc21602aa445fdb8fb575ec9',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/68107edb72b12446eabd7b5b0e542e95.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a7d3db6ca3d3b36399774bf1ae92c825',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/05170f7b845b8965bcc670412c29dbf3.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5475223efb33d9f7acd4f6139e1f28c',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/07288bc15a93225c06801a9e8557bde4.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e4529f862de20bb3b7ee8eb5d15dccaa',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/b6b47f5016f0ddb1b173b38ca61a257b.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '173b65c0e1133783c538c23008eb4e80',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/c2fe1751be6fd0dbeff948839061291e.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd97c3efd3e90e7d6723b171f4cc31379',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/008895cba0df78fb06f5f7ab001e68fd.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '069391235b11c982d30ec84c8a90d5f4',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/fd8b7e2dba755b97d758d1e6999f3abe.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1dd7892ed50dc9bb42cbad96a5660fbb',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/dc8b2d579cb58b217926b3730c4e5dc4.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '223da6571bb4f0f3916ed9af44da4f9c',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/8a3df840455f68d80cfed69add4e2d07.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2c208d29c74ecd9b3c7186bec0e3497d',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/cfa30991b820ec7db67b55e3b4dca927.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cdb20b558c1c5b6e5807f32b6d22c788',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/7b968d8c022f7740c6c3b123f364d3d1.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f63e68a2729bedec1618515c9f0f3993',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/f9e44709f5355c95a774a6c6a466d105.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '40051f206c63eb9228e3e7462c619662',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/d9fe442b296d0831bb0eb56dee13c3a6.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74b775a236c6b9076e331a8b25f837cb',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/fed3ac2f42379d3e3e6d710501270296.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '61936ac8e9cde8a2837d6ad5b4a5e044',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/a65a3e9979f9aebc8b03fe6a8931a3a3.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75bf97bc587255fb97966dc8c779477d',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/cfeb880320e34def838da23cf0c23a26.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd5d7c9dc4f850249aa52b5df050c4ab1',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/d7a1f31d897e9068f37881ca5443531c.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '57800d8006e8323ecf0a4f27bc200f54',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/bc0533973a1e8345a1f6cdfd2e68eb0a.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f04647b24dec84824e6e22e20ad518b4',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/63c1ee9c18a2b5c6d832cd09fe80ac9f.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc45c5dc7d3726e640bafd7f71eb2781',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/d4939a14f440a84c1dbbf0797d61fc2f.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5391ead53f6f3e3affc28ba049d08a4d',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/4cb35a770e734c37dc838272cbba08e8.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c283bbeaf757f42d3edf33324a139d0c',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/6bc56e11cb24f71b747cd4d035a11786.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '284678dfe13cd551d18a57e9dbd1a3e3',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/4b52c5fdca7c78534ec913525fc6b466.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac39077e1f6f98f888ed35f059ba2081',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/c67400946b927cf9f4b43b7dbcbfd5d5.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '78ee8f456f5569cf425f284dc64d3fcd',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/409587806a391a89d2ee9570418e8a74.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2726611841f34157a0fdbfdb1c95a6db',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/d23e82b3603d6b38ab2178bb02e74859.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '19bc37b55f314dd5328dfbd7352f93dc',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/f80134e5f5f4247dbae6541b43b7b198.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b2d656bcd924472ffd79a67fe9d07c8e',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/4ec49e8bd8019b520369d55032776702.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd136a8ab0790242920af78b9c366dd7c',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/89d10c8f76fae874c1b37c35ce199fb1.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '698e283e5ca92ff6eb5574b3df32af3a',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/5c17b2dbbb0c5adfed4cb0fb30c15a17.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ef5605a4eb154d49b46fcc87668da211',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/c2da0cdf521acc99a4a24ae63e42dc4f.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c597c9d2d389ff1df494ffb72a40ba7f',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/23d50b45636e9a75784859075c348ba5.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a5bde4954426076b9b752f693937af0',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/508a3282d7cf1d5b7dcff70cf966e747.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3de40f2f863bc4b269e6f8374448be44',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/537af835d9ce2bbf83c079c150db9f6c.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '16609368f8cbf314bc01acdf5f782377',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/2f03fb44c06524b917ec3a582f47417c.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a994f02e7a742e7813cee69f3e21036f',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/2caf93c1329667fad1738e60db7e12a2.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '073d8e5d43babae2baf2cf06175d78b9',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/38cdbcff144907f0c6e462b73affb10e.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22ad47270e93c164531a468ebf85b2e8',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/54185b8b34e2a1e02e60a120c6317be1.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be1bd1a74f0cd135ad87922a8105a4ca',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/a2d0d213b572332f395da8541b2591d1.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22d6bc8d303b760b0e9101ce4b590890',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/d4c637404dd0d618bf2b2643c06ddf80.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '771ce13e7036c9e5ac4023e1706a0504',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/ad6361cb0dfebcba6ca16c9eebf81042.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b2b09edac7cdfd1f31ab7fea3d2be193',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/6a03ac353ae7220d19c3bbb3b0fb4cf2.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '662313c28d237793f83a61af93de188e',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/c8e14ce2a93af340dae59d12f084e4ee.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5f825f440437d142dedbfc328edc2319',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/e89fff2e8d5f5d3688ae22bafd26d3c3.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'abd186bfbfa5a266e52543e223d07866',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/e091062f6942d70fd53b8a4f180829f0.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9f4669755a6bf2cfdb950b6db01fa7bc',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/eb39aebec2c59ba603ba2388c4b9e9cd.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c5884d5c0a208a811f088db7e4c2a3f',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/389f1f7eb98e31a5cc5bd1ddc6b6e011.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac92d04f1d0f4e05494b691c5f35d668',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/965f2a808c3282853501897535ed908a.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f56893de97d43e9b7a6620fb9803399e',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/686735f159a2cd41166b0370df60925d.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1d7b33b452e96047f7e041c411b238a9',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/ee1fd87bf9b2316a18e8e0cb10c8780a.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6aabdf134a77a7440944a557f3f83bce',
      'native_key' => 'upload_translit_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/33fc083e996e9d4a0c7f61d233854a3f.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31203508b8d4003c1ef9a0242d430a5f',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/acf0f91af38b7342dde7c2cd201b26dc.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5cde56d1b7f9411b11735ac80618f3e',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/fcf69891b0b855efd1d9c93b94216c01.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e835a29cf4b6538bc0a8ee3d50075dad',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/81d1320ed62ea1dc32782139ce1832c2.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e7286d6ebabe16efd783dc46568755f',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/30490174065a179aefb678f0548a90fa.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99233d3f4fc38a1ccf10c5a67bf91177',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/f3c95984efbba07dcee26f7681473efc.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e2dfcd3369c4ba96ca054bbf9c1b3ee1',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/ec311c29e4214ce8ac9a95ee68db7777.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bb5e8814c4fd22d01123d4d272fe553c',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/207d1ca4d4a3fa7fe16d2eb065be3c35.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f15cf1d33ed3ee46103beae003458168',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/df9ec2e43d18ab1a42ecda542a72c5ab.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6c74572820ce3d52151c4424326a145',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/6b5ea65f87d44f756aa61a50d140920a.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c6889721caf1abb17a69569f32629690',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/824ffd3c1548eb9031b1f39f47d370c7.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6b89d0370ee779e50689ca004c14c816',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/0b141068fa3d1de963809717b10dd64d.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a8ac4efce307b1d5d022808f9d4b8f97',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/5fae151a767541322340c4b39ecc1265.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b18b4bc203964bb2e987de9bff65f5d3',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/621111db9bb1242bbb11c1fd0c2831d9.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '10169a496f75f12a732479018d59cd30',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/64a681b3064cca4ae493f3e59abb8875.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9086eb9fed68533c31b0a6e4e399cb8a',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/ef917e9c9129791e346ed03eab5d77ec.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bf085498ccf5e12ab1e3262e73b28d23',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/a602b772c2b578f7b39c0714a2d3ba38.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd90868397df45045e37a8038135abf1c',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/e126fde9bcf0998b83465ffce5e5046c.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e12fed9d74eaa642ba4bfc6a2fe72f8',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/d9cfe454af3fb0522484652c816ff4f5.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bae2851f003264e830b3b163b1ffd533',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/22c59bed2136631b50d8d5e780e3ad71.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e91a9f528695b3972030b86cee03116b',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/f2ce731c76a7075c2a8557d18d4a32da.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37ddf3747376faf9161b550a58c50c52',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/e4679a8e69a909a1d4176001ee132587.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c53f5ada29f45d26e7e9b5d4e63580d',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/feccdd75bd70aaab67d8b2c8e72570dc.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1adcc354322767d7dde5437470e74bc9',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/a090a34e48a6901a0dcea970ca49f202.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ba2eac2a35edbd78fbde0d3b215a7452',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/be1839ea078af3f432ca2ea0d85df804.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2ac1cd243ea0f38e9de02cac0147ae82',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/de1e70a80feb0ba175d1f44b738a0dac.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c75f7b7b53040f78e3a1ba84a02b68ab',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/f3a37e203d7ca5407ee3088f11a877cf.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '0a95495a5be5eb0d620cc7bde73ff439',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/7df1f9c536e23ab1b37bace4a48ee94f.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '57d32774bc5619d9f12397f9d4b18de8',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/1fbf0d0429e454fb89d23f661c4e22f9.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => '3a3578e931c8d5c0250eebd0f77f1d2f',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/b324dc262a5f90c0ffcd536b4c087aa2.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => '852f36f48058dea90bef1410b725cbc6',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/a5c4a2bebb9860bbea2c6ff7fb7c5b49.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => '9f8802630f479ce401b7b34a3edc2e79',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/3321f71022cbc0831721481b310fecc7.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '64655bdf0d3dc0ecfb77b2befe887913',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/b460e682204f9d9f12c49b3a68c0a5f1.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'aba5ec8fa92ed2584fe1758da5cd07ba',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/1a216728550f1e54a3ec174c11fd2bc9.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '7882d8a4bb3ef7de9f7c2d3bb054ffbb',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/7862bfbbeaecd1bef2b5da5b846c79a1.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '607cd9c57660dceabc5f86d6cf7a2129',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/f82e47e9064039c78d05cd0915e8d9d6.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'e438396e7986720206afb65b8bed675b',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/94865ec5e5bc28a3be0fb7caf4f4a3df.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '65e54d0499882771426287987b8b6d1c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/e0467f5909aad09ccbed8b9039c03cd6.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'f71b7f7645585c37fa33cc54b1b36ecf',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/56fcdb0bf538e36fa4cdb35c9f58877a.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '686977a6860c95555168303d30033f84',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/f1646763512ac71c08bac3f66211ebc4.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '9d250f55e289bc3930ecc4fc347f993d',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/88446798a73935343d542411f919a7eb.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '5976442a88868ac772181f9ab8ce8bd5',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/193fad5d0e6e21ab3767abec5003044e.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '5412fd9682cb722f1e49ea2dfc060fc2',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/9a0674452e8a394331367d29783e61a9.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'e924faca3ed07009c0c4c9ffcb409d43',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/d74f81f4fb0b87abe23154b6d55d853d.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '8428866e79173d93470b5a8cbcb5d603',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/2d72cfd55ad1ee99188f2ce3317f5ce6.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '0ec428318eace351b7acef5692f8f689',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/7f5a6b624ae820bc1b0ac8bdf16ab8a8.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '4dfa28a1d1aff513500bdc121e15ceb1',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/72a877120723f2515e9b343200ae6191.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '68d62160c45784de915b93755fa21260',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/e24351e740e531deb212f4ee101a176d.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'b117d731712fa68bcaee3157ed4f2230',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/70933612b3d71a4c0b3f471cd05420a2.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '53d4cd111dd66248046040201367c1c4',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/27756550509c969b61417ab8d968cb4e.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '80e543de845aa811fb3c79411f97c2bd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/23e6c3dbeb19e9f7d08519fdd49f26da.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '68736f90d47700a3ec442016b93327f5',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/a5057c1df598d8e649192258dd35aa01.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'afb066ed1021daa17eac35a51f8a99e9',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/32b8ca234a80b95571ce37dbab80b4d6.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '7b3fe8e60e4beaf16a9875afc19bd2ad',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/2f8c3bcd0e14ee9679e6df1ecd81fa0a.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'c26ddb1e071e782ffb24ccb55337abb0',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/a57c968f5d19131e28ab7b3065786e81.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'b198b73bb9bff53480a0b93107936481',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/8698788bed7b04537b7aef65560f5440.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '30b07a7f0d10564b643eb3d0024331ea',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/0dffce71fb288635fff4ff6c0b51549d.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '09abe4e4bf2c5497c13a68b61d3c12e7',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/a635d61cadaee223c35e029abbbdbe2f.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '4636e9a657e7065cb2c1802c8027c47c',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/dbe1a1a1af3e9bdb8a5f0d2a07b1f662.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '2da32031f98f7c1b548cd8fa14a6f38a',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/b845ed07e4f6b8237c0bdae08bd86604.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '92585a3b1500f9d0cad980f48522d257',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/54b30783c767c1540f4e5daca780f603.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c5dd99ef8559ee784ca752cc7df6235d',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/f9d6acc279a7191f4530ddb0b9d8aee7.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'e7d2db34215bb73283e86afe21336a17',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/24f1d534aff51b691280e5af54667f54.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '24aa3cf2c07e87b888925ca6a7d64961',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/b3a41e14670b54da4a397ffd0f65f043.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '3ab314e272833fdaa12da38ab4d54d4d',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/a8cb48f1685a5de114ebf5e714ef62cb.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '0bfc93df73915890dc5ed7a2780c9e12',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/07709dec409c20341293f22495cde223.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'b28aa5444e67ccbe35924361dc8a3e5c',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/3fffc7ec27a6b21b6b4bfd618842442e.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '6b169d57997083e6ebbe8be6fe6e842f',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/7348afb290bd39b64b64a82ecbcb2b64.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '92bf61c43f3e182b833746d6515d5371',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/e3a5fe2a88348bec819e2498fda2cd30.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '1ed0af4559281be056fcbf80f62bb1d7',
      'native_key' => '1ed0af4559281be056fcbf80f62bb1d7',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/46af2d69d79f0b963efbb5bf77a2a6e4.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'a196a08a12ad9cc95f03d49a91c4384d',
      'native_key' => 'a196a08a12ad9cc95f03d49a91c4384d',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1ee95bf46b9d2c1b303fa8a02fffe105.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '9e01f4b745e0cf406771e7a9f1823b11',
      'native_key' => '9e01f4b745e0cf406771e7a9f1823b11',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/fcadace485b4fbc6397a16821dacbb68.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '7aad986be64b00affe7877882c0a9317',
      'native_key' => '7aad986be64b00affe7877882c0a9317',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/a7fcdb3461610e07f20e2a0f2516ea2b.vehicle',
    ),
  ),
);