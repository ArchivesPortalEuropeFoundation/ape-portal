<?php
require_once (dirname(dirname(__FILE__)) . '/mgyoutubevideo.class.php');
class mgYouTubeVideo_mysql extends mgYouTubeVideo {}