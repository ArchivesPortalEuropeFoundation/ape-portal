<?php
require_once (dirname(dirname(__FILE__)) . '/mgmediamanagerimage.class.php');
class mgMediaManagerImage_mysql extends mgMediaManagerImage {}