<?php

$_lang['moregallery.permission.view_gallery'] = 'Toestemming om de galerij te zien op een resource.';
$_lang['moregallery.permission.upload'] = 'Toestemming om nieuwe afbeeldingen te uploaden.';
$_lang['moregallery.permission.import'] = 'Toestemming om afbeeldingen te importeren vanuit de media browser.';
$_lang['moregallery.permission.import_media'] = 'Toestemming om media te importeren vanuit Sterc\'s Media Manager extra.';
$_lang['moregallery.permission.video'] = 'Toestemming om videos aan de galerij toe te voegen.';
$_lang['moregallery.permission.resource_settings'] = 'Toestemming om galerij-gerelateerde instellingen op de resource te bewerken.';
$_lang['moregallery.permission.image_active'] = 'Toestemming om een afbeelding als actief of inactief te markeren. Hiervoor is ook de image_edit toestemming nodig.';
$_lang['moregallery.permission.image_delete'] = 'Toestemming om een afbeelding uit een galerij te verwijderen.';
$_lang['moregallery.permission.image_edit'] = 'Toestemming om informatie over afbeeldingen te bewerken.';
$_lang['moregallery.permission.image_tags'] = 'Toestemming om tags te beheren die aan een afbeelding zijn toegevoegd. Hiervoor is ook de image_edit toestemming nodig.';
$_lang['moregallery.permission.image_tags_new'] = 'Toestemming om nieuwe tags aan te maken die nog niet eerder zijn gebruikt. Hiervoor is ook de image_tags toestemming nodig.';
$_lang['moregallery.permission.image_crop_edit'] = 'Toestemming om crops op een afbeelding te bewerken. Hiervoor is ook de image_edit toestemming nodig.';
