<?php

/**
 * @package moregallery
 * @extends ResourceDataManagerController
 */
class mgResourceDataManagerController extends ResourceDataManagerController {

}
