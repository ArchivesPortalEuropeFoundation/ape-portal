<?php
require_once (dirname(dirname(__FILE__)) . '/moregallery.class.php');
class Moregallery_mysql extends Moregallery {}