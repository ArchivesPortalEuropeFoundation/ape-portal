MagicPreview for MODX
---------------------

MagicPreview adds a _Magical_ Preview button to the resources panel which will
show you, without actually saving the resource, a real preview of a resource.

It also has responsive breakpoints, so you can preview your page on various widths.
