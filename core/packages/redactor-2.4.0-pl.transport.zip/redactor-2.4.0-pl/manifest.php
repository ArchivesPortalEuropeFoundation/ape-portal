<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'modmore is a valid license holder of the Redactor OEM license by Imperavi.

This license is a legal agreement between you and modmore for the use of the Redactor for MODX Extra. By downloading or installing Redactor, you agree to the terms and conditions of this license. modmore reservers the right to alter this agreement at any time, for any reason, without notice.

This license is valid for a single MODX installation and may not be redistributed, changed or removed of its license.

===== Included for reference, the Redactor OEM License ====

This license is a legal agreement between you and Imperavi for the use of Redactor (*all versions*) Software (the “Software”). By downloading any version of redactor you agree to be bound by the terms and conditions of this license. Imperavi reserves the right to alter this agreement at any time, for any reason, without notice.

Restrictions
Unless you have been granted prior, written consent from Imperavi, you may not:
Reproduce, distribute, or transfer the Software as a sole product, or portions thereof, to any third party.
Sell, rent, lease, assign, or sublet the Software as a sole product or portions thereof.
Grant rights to any other person.
Use the software in violation of any Canadian or international laws or regulations.
Display of Copyright Notices
All copyright and proprietary notices and logos (if any) of Redactor/Imperavi and within the Software files must remain intact.

Making Copies
You may make copies of the Software for back-up purposes, provided that you reproduce the Software in its original form and with all proprietary notices on the back-up copy. You may include copies of the Software as an integral part of your product (according to Permitted Use stated above).

Software Modification
You may alter, modify, or extend the Software for your own use or for use in as an integral part of your product or service, or commission a third-party to perform modifications for you, but you may not resell, redistribute or transfer the modified or derivative version of the Software as a sole product without prior written consent from Imperavi. Components from the Software may not be extracted and used in other programs without prior written consent from Imperavi.

Technical Support
Technical support is provided by email. No representations or guarantees are made regarding the response itself or response time in which support questions are answered. For the Support License holders response is guaranteed and the response time is no more than 1 (one) business day (Friday requests are answered on Monday; afternoon requests are answered next day).

Refund Policy
We offer a 30 day money back. If for any reason Redactor doesn’t work out for your project, simply email us within 30 days of purchase for a full refund.

Indemnity
You agree to indemnify and hold harmless Imperavi for any third-party claims, actions or suits, as well as any related expenses, liabilities, damages, settlements or fees arising from your use or misuse of the Software, or a violation of any terms of this license.

Disclaimer Of Warranty
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF QUALITY, PERFORMANCE, NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. FURTHER, IMPERAVI DOES NOT WARRANT THAT THE SOFTWARE OR ANY RELATED SERVICE WILL ALWAYS BE AVAILABLE.

Limitations Of Liability
YOU ASSUME ALL RISK ASSOCIATED WITH THE INSTALLATION AND USE OF THE SOFTWARE. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS OF THE SOFTWARE BE LIABLE FOR CLAIMS, DAMAGES OR OTHER LIABILITY ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE. LICENSE HOLDERS ARE SOLELY RESPONSIBLE FOR DETERMINING THE APPROPRIATENESS OF USE AND ASSUME ALL RISKS ASSOCIATED WITH ITS USE, INCLUDING BUT NOT LIMITED TO THE RISKS OF PROGRAM ERRORS, DAMAGE TO EQUIPMENT, LOSS OF DATA OR SOFTWARE PROGRAMS, OR UNAVAILABILITY OR INTERRUPTION OF OPERATIONS.
',
    'readme' => '------------------------------------------------------
Redactor - Sexy RTE/WYSIWYG Editor for MODX Revolution
------------------------------------------------------
Author: JP DeVries, Mark Hamstra - support@modmore.com
------------------------------------------------------

Redactor is a commercial-grade Rich Text Editor developed by Imperavi, tightly integrated into MODX by modmore. Redactor for MODX has all the features you would expect in a rich text editor with all the flexibility you expect from MODX and modmore.

The media management in Redactor is optimized for client use, providing the site builder with lots of power to enforce upload and selection rules.

For a full list of features and configuration, please check the website: https://www.modmore.com/extras/redactor/
',
    'changelog' => 'Redactor 2.4.0-pl
-----------------
Released on 2020-01-04

- Fix MODX3 alpha compatibility issues in media browser
- Fix fixed toolbar positioning in MODX3
- Remove unused plugin events from package: OnTVOutputRenderList, OnTVOutputRenderPropertiesList, OnManagerPageBeforeRender, OnRichTextBrowserInit, OnDocFormPrerender
- Update build to use encryptedVehicle 2.1 and proper minimum requirements check

Redactor 2.3.9-pl
-----------------
Released on 2019-12-19

- Don\'t register a TV output type; that\'s not used and can cause side-effects with custom plugins
- Small license check fix

Redactor 2.3.8-pl
-----------------
Released on 2019-09-06

- Fix upload errors being returned in wrong format [S20839]
- Make sure errors are shown in a nice popup

Redactor 2.3.7-pl
-----------------
Released on 2019-08-06

- Prevent rendering the content field if ContentBlocks is used. This improves manager performance and prevents errors from getting triggered in the developer console (with ContentBlocks 1.8.12+).
- Fix hardcoded numbers in the replacer window (redactor-plugins@1.2)
- Add new plugin_replacer_button setting that lets you add a button for the find & replace functionality

Redactor 2.3.6-pl
-----------------
Released on 2019-07-11

- Prevent Codemirror plugin from breaking resource save in some cases due to JS error [S20434]

Redactor 2.3.5-pl
-----------------
Released on 2019-06-13

- Catch exceptions in media source when trying to list files or directories outside open_basedir [S19733]
- Prevent invalid HTML from breaking the baseurls plugin, which in turn would prevent content from being stored [S20288]
- Fix typing "a" with linebreaks mode and baseurls plugin breaking the manager

Redactor 2.3.4-pl
-----------------
Released on 2019-02-19

- Fix missing translation for aligning images in the center, by re-using alignment strings for text alignment [S17648]
- Fix E_NOTICE undefined index "style" when the style is not defined on custom formatting [S19277]
- When using multiple classes in a formattingAdd style, the styles now apply in the dropdown too [S19277]
- Fix replaceTags setting not working [F1733]
- Fix plugin for linking to resources missing from Redactor TVs [F1723]
- Fix redactor.linkResource setting not having any effect; it now toggles the custom linking tabs (resource, email, etc) [F1732]

Redactor 2.3.3-pl
-----------------
Released on 2018-07-04

- Fix package installation on MODX3
- Fix broken editor in MODX3 due to missing language (stored in session instead of setting)

Redactor 2.3.2-pl
-----------------
Released on 2018-02-06

- Add Ukrainian language file [S14393]
- Fix license check running daily instead of weekly

Redactor 2.3.1-pl
-----------------
Released on 2017-08-10

- Fix incorrect falling back to default media source instead of redactor-specific settings [S12760]

Redactor 2.3.0-pl
-----------------
Released on 2017-07-10

- Allow custom (inline) formatting to be applied to headers

Redactor 2.2.3-pl
-----------------
Released on 2017-05-04

- Revert change to Fix buttonsHide settings which caused a breaking change

Redactor 2.2.2-pl
-----------------
Released on 2017-05-02

- Fix Bold/italic/underline etc don\'t work in Chrome [#456]
- Fix buttonsHide settings, set these as comma separated lists

Redactor 2.2.1-pl
-----------------
Released on 2017-04-07

- Add new `root-relative` baseurls mode value for subdirectory-based contexts with shared assets in the site root [S11174]
- Fix potential jQuery conflicts affecting Redactor template variables [S11205]
- Fix context-specific redactor.css setting not being recognized [#443]
- Fix Rich Text TVs on symlinks/weblinks/static resources not getting enhanced [#449]
- Add missing video plugin control on Redactor TVs [#441]
- Fix Dutch translation of "paragraph" [#413]
- Fix for redactor.removeAttr and redactor.allowedAttr syntax
- Fix Search/Replace plugin [#447]
- Fix unintentional typeahead in Edit Image > Alt Text field [#453]

Redactor 2.2.0-pl
-----------------
Released on 2016-05-19

- Fix predefinedLinks plugin
- Hacked redactor.js to add support for multiple modal callbacks

Redactor 2.2.0-rc2
------------------
Released on 2016-05-03

- Fix file path issue with dom4 and no-flexbox polyfills which broke the browser in certain browsers
- Fix issue causing file browser to not open to redactor.file_browse_path
- Fix uncaught type error in Eureka Media Browser when media source is not yet set

Redactor 2.2.0-rc1
------------------
Released on 2016-04-29

- All new Full Screen view in Eureka media browser model
- Eureka: New messaging "no files found" messaging
- Eureka: Separate Storage Prefix for Files and Images [#417]
- Eureka: Setting to disable localStorage via hidden eurekaUseLocalStorage setting [#418]
- Eureka: Control whether of not fullscreen mode is available via hidden eurekaAllowFullScreen System Setting
- Image Title Renamed to Alternative Text [#401]
- Removing references to autoresize [#394]
- Exposed redactor.initial_directory_depth Setting with a default value of 3. This means the Eureka Media Browser connectors will now attempt to recursively list directories three depths deep.

Redactor 2.1.1-pl
-----------------
Released on 2016-04-14

- Fix Broken Link Anchor Tab
- Image and File Browsers now use separate local storage cache keys
- Eureka: Separate Storage Prefix for Files and Images [#417]
- Eureka: Setting to disable localStorage via hidden eurekaUseLocalStorage setting [#418]
- Removing references to autoresize [#394]

Redactor 2.1.0-pl
-----------------
Released on 2016-03-29

- All new "List" View in Eureka Media Browser
- Fix Eureka upload button in Firefox [#405]
- Fix some buttons not available for TV usage [#416]
- Eureka: Option to disable enlarging of focused rows by creating an enlargeFocusRows System Setting set to false
- Fix compatibility with FileSluggy and similar extras [#398]
- Fix some buttons not available for TV usage [#416]
- Fix issue preventing images with uppercase extensions from showing [#404]

Redactor 2.0.7-pl
-----------------
Released on 2016-02-02

- Fix Eureka Media Browser Layout flips out completely on Chrome 48 [#399]

Redactor 2.0.6-pl
-----------------
Released on 2016-01-15

- plugin_uploadcare System Setting now defaults to false
- Respect Selected Text When Inserting Files [#384]
- Fix Weird Clips Behavior [#388]

Redactor 2.0.5-pl
-----------------
Released on 2015-12-23

- Restore the resource typeahead on image links [#372]
- Switching redactor.pastePlainText System Setting to default to false [#375]
- Fix Advanced Attributes don\'t persist in modal [#392]
- Insert Images by URL (See plugin_imageurl Setting)
- Fix issues with Formatting and Custom Formatting options not being used on Redactor TVs [S7400]
- Fix persistence of plugin-related Redactor TV options [S7400]
- Fix disabling plugins on specific Redactor TVs if they\'re enabled globally [S7400]
- Make sure Redactor TV options use the setting lexicons for better and translated descriptions [#109]

Redactor 2.0.4-pl
-----------------
Released on 2015-11-04

- Fix broken flexbox layout on touch devices [#387]
- Fix incorrect choose title when eureka upload is enabled [#386]
- Fix layout when Eureka sidebar is collapsed [#385]

Redactor 2.0.3-pl
-----------------
Released on 2015-10-27

- Fix incorrect link text on convertLink [#374]
- Fix issue with Clips not inserting inline HTML [#378]
- Fix incorrect check causing E_NOTICE errors in upload
- Fix bug with some upload path placeholders not working

Redactor 2.0.2-pl
-----------------
Released on 2015-10-01

- Update Redactor.js to 10.2.5 with several bug fixes
- Fix Eureka growing beyond available size with lots of directories [#367]
- Fix email links adding double mailto: [#368]
- Fix Eureka breaking out of the modal [#370]
- Improve consistency in modal styling [#371]

Redactor 2.0.1-pl
-----------------
Released on 2015-09-16

- Fix thumbnails not showing in certain environments [S6479]
- Fix Broken Image Edit Window [#366]
- Fix various z-index issues when used in MIGX and other components [S6480]

Redactor 2.0.0-pl
-----------------
Released on 2015-09-08

Redactor 2 is here! For the full details of the 2.0 release, please check the changelog for Redactor 2.0.0-rc2 below,
or visit https://www.modmore.com/blog/2015/announcing-redactor-2.0/ for the official announcement.

Fixes in 2.0.0-pl since 2.0.0-rc8:
- Fix loading of Eureka with js compression enabled [#354]
- Fix loadIntrotext not working in certain edge cases

Redactor 2.0.0-rc8
------------------
Released on 2015-09-05

- Show size of image while resizing [#95]
- Fix potential E_NOTICE error when dealing with ultimate parent [#353]
- Fix redactor.date_files not being respected on file uploads [#350]
- Fix dynamic thumbnail being missing from Eureka [#349]
- Fix switching back to visual mode with ace editor on TVs [#355]
- Prevent loading Ace multiple times when used on TVs
- Load Ace from CDN with fallback
- Fix missing limiter setting and incorrect format
- Fix Ace Editor In TVs (and not main content)
- Ensure un-ordered lists are bulleted with list-style-type:disc
- Breakout Media Source TV Input into File/Image [#362]
- Fix marginFloatLeft and marginFloatRight [#360]
- set redactor.linkTooltip to default to true

Redactor 2.0.0-rc7
------------------
Released on 2015-08-15

- Fix bug introduced in rc6 that prevented editing chunks

Redactor 2.0.0-rc6
------------------
Released on 2015-08-15

- Remove searchImages Setting
- ImagePX Plugin Fix (thanks for the Pull Request YvonneYu)
- Fix No Eureka on RedactorTVs [#351]
- Updated Eureka Media Browser localStorage keys to be more specific
- Allot Media Browser Stage more pixels [#328]
- Updated Redactor.js to 10.2.3

Redactor 2.0.0-rc5
------------------
Released on 2015-08-03

- Fix issue where saving a resource duplicated Redactor TVs [#344]
- Fix issue with Clips plugin causing fatal JavaScript error [#346]

Redactor 2.0.0-rc4
------------------
Released on 2015-07-30

- Added ability to use different media sources for uploading and browsing files vs images (does not effect Eureka browser) [#331]
- Fix issue with path placeholders not working as expected [#333]
- Fix issue where uploading files used the configured image path [#334]
- Fix issue with opening eureka for inserting files [#335]
- Fix issue where disabling eureka did not fallback to the legacy browsers [#336]
- Fix browse issue when using legacy (non-eureka) browser [#338]
- Fix broken source mode when using CodeMirror and a Redactor TV [#330]
- Only show images when browsing images in Eureka [S6009]
- Fix dropdown position when toolbar is fixed [S6009]
- Improve compatibility with dynamic media source paths using snippets relying on $modx->resource [#322]
- Fix issue where in some cases TVs that are moved to a new tab with form customizations have no toolbar

Redactor 2.0.0-rc3
------------------
Released on 2015-07-24

- Fix issue with right-side of the manager not loading after update to 2.0 on certain environments
- Fix issue with incorrect media source being initially chosen
- Fix issue where toolbars on TVs were hidden until scrolling [#321]
- Fix issue with fixed toolbars getting stuck when going to fullscreen mode [#324]
- Fix Root Directories not Expanding when selected [#326]

Redactor 2.0.0-rc2
------------------
Released on 2015-07-20

Redactor for MODX v2 is here! Our second major release of Redactor is based on v10.2.2 and ships with a lot of new features and improvements.
For upgrade notes, please visit https://www.modmore.com/redactor/documentation/upgrading-1.x-to-2.0/

Redactor.js v10 highlights:
- Largely rewritten with a modular design with 36 core modules and over a dozen plugins
- Dozens of new settings, callbacks and APIs
- Fixed 60+ formatting issues and 100+ other core editor bugs
- See http://imperavi.com/redactor/docs/whats-new-10/ and http://imperavi.com/redactor/log/ for more Imperavi updates

New Features:
- New, more powerful and better looking Media Browser for inserting images or files
- Syntax Highlighter Support for the source mode powered by Ace or CodeMirror (#262)
- Path placeholders now include Template Variables (with [[+tv.name_of_tv]]), parent alias, ultimate parent alias and all resource fields (#199)
- All settings are now context-aware, allowing per-context overrides on Redactor configuration (#146, #275)
- New custom formatting baked into the core (#260)
- Tagging for Clips plugin allows to find specific clips quicker (#250)
- Ability to set images dimensions in pixels
- Add subject, CC and BCC field to the Insert Link > Email tab as advanced attributes (#203)
- Optionally add a Redactor editor to the introtext (#243)
- Also see the list of Plugins below for more exciting new or improved optional features.

Improvements:
- Uploading images and files now requires the file_upload permission (#159)
- Boolean setting values are now properly recognized (#266)
- Improved handling of image urls, which are now relative to the site base url by default (#288)
- Updated jQuery to 1.11.3
- Show context on hover in Insert Link > Resource typeahead (#204)
- Prevent overwriting existing files by adding an incremental index to filenames instead (file sources only, #198)
- Better abstraction of MODX/modmore-specific overrides for faster Imperavi updates
- Fix issue with using typeahead on third party components (#248)
- Fix issue with attempting to create thumbnails of .svg images (#246)

Includes plugins as of Redactor 2.0:
- Base URLs: normalizes image src attributes to ensure clean output
- Breadcrumbs: shows the markup hierarchy from the cursor
- Clips: easily insert configurable snippets of code or special characters
- Contrast: hit f5 to inverse the editor colors for high contrast mode, works best in full screen
- Counter: shows the length of your content, and approximately how long it will take to read
- Defined Links: allows setting up predefined links that are available in a dropdown when adding a link
- Download: downloads the html source of what\'s in the editor to file
- Eureka: shiny new accessible media browser
- File manager: upload files or browse existing one with Eureka
- Font color: change the color of part of the text
- Font family: change the font family of the text
- Font size: change the size of the text
- Fullscreen: make the editor full screen for more immersive writing
- ImagePX: provides extra options in the image window to specify the size of an image in pixels
- Limiter: makes sure the content does not exceed a certain limit
- Norphan: prevents orphaned words at the end of sentences by adding a   between the last and second last word
- Replace: simple find and replace utility (#254)
- Speek: listen to your written words being spoken with the power of HTML5 speech APIs
- Syntax: use the Ace syntax editor for the source view; codemirror is also available
- Table: the table features that were available before are now available as separate plugin
- Text Direction: set the text direction of a block-level element
- Text Expander: expend small pieces of text into a larger one
- UploadCare: as alternative to locally hosting images, UploadCare lets you upload directly to their service from Redactor

Removed features and breaking changes:
- Please see the upgrade notes at https://www.modmore.com/redactor/documentation/upgrading-1.x-to-2.0/

Redactor 1.5.3-pl
-----------------
Released on 2014-12-30

- Fix issue browsing images when there is only one image in the browse folder.

Redactor 1.5.2-pl
-----------------
Released on 2014-11-07

- Load the current resource more definitively to cover some edge cases where the resource is not in the modX scope
- Loosens Patch 11291 Conditional which caused asset paths to break in Revolution 2.3.2+
- Lexicon Updates

Redactor 1.5.1-pl
-----------------
Released on 2014-10-29

- Fix z-index issue when used with MIGX
- #244 Fixes Adding Classes via Custom Formats

Redactor 1.5.0-pl
-----------------
Released on 2014-08-14

- Several all new features!!! See Redactor 1.5.0-rc1 release notes below for more info https://www.modmore.com/blog/2014/announcing-redactor-1.5/
- Added Hidden Mobile Buttons to TV Level
- Lexicon Updates

Redactor 1.5.0-rc2
------------------
Released on 2014-08-08

- Some more design tweaks in modals and fields for better consistency
- Fix "undefined" placeholder for linking to resources
- #235 Fixed toolbar offset height in MODX 2.2.x
- #237 Fix Linking issue when editing images
- #238 Fixed underlapping toolbar issue
- Added toolbarFixed and toolbarFixedBox settings
- Fix setting lexicon keys for predefinedLinks and shortcutsAdd

Redactor 1.5.0-rc1
------------------
Released on 2014-08-05

- ALL NEW Custom Toolbars Feature!!! https://www.modmore.com/redactor/toolbar
- New Custom Formats WYSIWYG Widget https://www.modmore.com/extras/redactor/documentation/creating-custom-formats#/custom-formats
- Now easier to link image to resources with new typeahead feature
- New Predefined Links Feature for quicker editing
- Added rebeccapurple support to all color settings
- Fix the toolbar within the editor box so it\'s always in screen
- #100 Properly report error to user if upload failed for whatever reason
- Make tweaks to the CSS to make Redactor blend in with 2.3 even better
- Use proper dependency injection model in plugins
- Prevent excessive error logging in 2.3.0
- Added $redactor->versions support for third party packages to determine Redactor\'s version
- Updated fontcolor plugin
- #224 Fixed Editing Link URLs in Firefox
- #219 Fixed Broken Modal in Fullscreen mode
- #194 Fix clearing margins when un-floating images
- #184 Fixed tab inserts "1" bug
- #214 Table pasting issue
- #202 Open in New tab when linking to a file
- Updated redactor.js to 9.2.6
- - New Typewriter mode
- - Hidden Mobile Buttons
- - Toolbar Overflow
- - Image Tab Link Setting
- - Clean Spaces Setting
- - Additional Shortcuts
- - Many bug fixes. See more at http://imperavi.com/redactor/log/


Redactor 1.4.3-pl
-----------------
Released on 2014-07-28

- #227 Enables a patch for broken asset paths. If running MODX 2.2.15 - 2.3.1, Redactor will attempt to patch broken asset URLs caused by modxcms/revolution#11291. To disable create a redactor.patch_11291 System Setting and set to \'No\'.

Redactor 1.4.2-pl
-----------------
Released on 2014-07-07

- #217 Fixes broken image thumbnails when inserting images from a search result
- #221 Loosen image search sensitivity
- Fix typo causing OnRichTextEditorInit event from not getting checked.

Redactor 1.4.1-pl
-----------------
Released on 2014-04-11

- Ensure Redactor TVs have access to the Resource data for upload/browse path placeholders
- Fix loading the proper RTE based on context settings
- #153 Fix E_NOTICE error in redactor class because of check for pre-2.2.9 S3 issue
- Fix lexicon entries for new settings in 1.4.0
- Ensure that the English language set is used as default to prevent undefined issues.

Redactor 1.4.0-pl
-----------------
Released on 2014-02-13

- New Advanced Attributes feature for WYSIWYG editing of classes and ids on images and links!
- 25 New Languages
- Update to Redactor 9.1.9 with several bug fixes!
- Update to jQuery 1.11.0
- #175 Prevent Images from loading until Choose tab is selected
- #176 Fix issue when loading Redactor on non-CMP pages
- #171 Fix undesired base path appended on Edit Link window (set linkProtocol to empty)
- #169 Fix colors in FontColor plugin
- #168 Add Anchors to Links (via Advanced Attributes)
- #94 Add optional class field to images (via Advanced Attributes)
- #163 Add extra placeholder for upload paths (pagetitle, alias, context_key)
- #160 Add linkNoFollow System Setting
- #155 Fix choose file/image when there is only 1 result
- #80 Fix View Source overlapping save buttons

Redactor 1.3.5-pl
-----------------
Released on 2013-11-18

- Fix problem with redactor loading in the content area (reverts #140)

Redactor 1.3.4-pl
-----------------
Released on 2013-11-18

- #143 Fix issues with link* settings
- #140 Ensure Redactor loads in MIGX DB

Redactor 1.3.3-pl
-----------------
Released on 2013-11-14

- Updating to Redactor 9.1.7
- Update to jQuery 1.10.2
- Add [[+day]] tag for dynamic file and image upload paths
- #150 Fix bug with unordered lists in Clips JSON
- #136 Default observeLinks to true

Redactor 1.3.2-pl
-----------------
Released on 2013-10-18

- Add sanitizePattern and sanitizeReplace settings to tweak upload file name sanitization
- Fix issue with page not reloading when creating resources that have a Redactor TV.
- Improve loading in custom components that are built with modManagerControllerDeprecated
- Fix bug with incorrect paths when using the Choose files functionality.
- Update to Redactor 9.1.5:
- - Fix several issues with outdent, video links and uploading
- - new image and file parameter configuration
- - new xhtml setting making code produced by Redactor more XHTML-compatible
- - new linkSize setting to allow links to be truncated
- - improves parsing of Vimeo links
- - improves performance on large texts
- - improves compatibility with IE 7.
- Update to Redactor 9.1.4:
- - fix observeLinks tooltip compatibility when in fullscreen mode
- - fix IE9-10 issues with clipboard paste.

Redactor 1.3.1-pl
-----------------
Released on 2013-09-17

- Ensure linkProtocol can be disabled.
- #52 Ensure floated images stay in their WYM container
- #91 Changing image position improperly unset margins/classes from the former position
- #127 Default to editor_css_path setting if redactor.css is empty
- #128 Fix description of file browse path setting
- Update to Redactor 9.1.4, which fixes observeLinks functionality in iframe and fullscreen and IE9-10 issues with clipboard paste. http://imperavi.com/redactor/log/
- #135 Restore missing CSS since 1.3.0.
- #134 Fix resource search with Redactor TVs
- #133 Fix missing styles for list items

Redactor 1.3.0-pl
-----------------
Released on 2013-09-09

- Update to Redactor 9.1.3 which fixes many formatting and pasting issues and adds copy-paste image support for uploads! Pasting images to S3 Media Sources requires MODX 2.2.9 or later. Thanks to Jan Peca for the MODX 2.2.9 fix!
- Added drag and drop for images support. Just drag images right into the content area!
- Images can be moved/dragged across text.
- Rewritten and improved image resizing.
- Link parsing for images and videos. Paste URLs to images YouTube or Vimeo videos to auto embed.
- Option to open links in new tab.
- Paste as plain text.
- Removed toolbar color selector
- Added color selector plugin
- New tidyHtml setting - allows to turn off nice output code formatting.
- New observeLinks feature allows to follow/edit links by putting cursor to the link
- #130 Add system setting for removeEmptyTags
- #131 Fix for missing styles in iFrame mode

Redactor 1.2.8-pl
-----------------
Released on 2013-09-05

- Fix Redactor TVs when the language is set to something other than English.

Redactor 1.2.7-pl
-----------------
Released on 2013-08-22

- #121 Add [[+id]] placeholder to paths to insert resource IDs.
- Only load clips and styles plugin on TVs when necessary.

Redactor 1.2.6-pl
-----------------
Pre-Released on 2013-08-15
--------------------------

- #123 Mail to tab on insert link modal now is available by default
- #124 Fix issue when displaying image subfolders when choosing images
- #125 Add browse configurations for images and files to Redactor Template Variables
- #118 Fixes issue with remote media sources

Redactor 1.2.5-pl
-----------------
Released on 2013-08-06

- Fix issues with MIGX ("$ is undefined" errors)
- Fix odd issue on PHP 5.3 with not loading the scripts.

Redactor 1.2.4-pl
-----------------
Released on 2013-08-05

- Fix issues with redactor.additionalPlugins.
- Fix issue with regular richtext TVs not loading Redactor.

Redactor 1.2.3-pl
-----------------
Released on 2013-08-04

- #117 Add Custom CSS stylesheet in non-iframe mode
- #113 Add insert advanced option to Styles JSON (set "advanced":"1") to use insertHTMLAdvanced
- Renamed Iframe CSS Setting to Stylesheet

Redactor 1.2.2-pl
-----------------
Released on 2013-08-02

- #112 Improve Styles JSON compatibility
- #113 Consider code tag text-level semantic element (not block)
- #114 Add forceBlock option to JSON

Redactor 1.2.1-pl
-----------------
Released on 2013-08-02

- #110 Fix console error with Clips plugin
- #111 Custom Formatting: wrap inline for text-level semantic tags

Redactor 1.2.0-pl
-----------------
Released on 2013-08-02

- #99 Fix air toolbar not showing in fullscreen mode
- #107 Default media source for Redactor to value of default_media_source setting
- #16 Add ability to load custom plugins through a system setting definition.
- #108 Slightly change text to indicate you need to start typing to find resources.
- #48 Refactor to make use of OnRichTextEditorInit plugin event to allow using Redactor in other components.
- Update to Redactor 9.0.4 to fix amoung other things issue when switching between visual and source code mode in Firefox, pasting in iOS and inline styles. http://imperavi.com/redactor/log/
- #44 Add custom formats like TinyMCE
- #69 Add Clips Plugin
- #105 Add base tag when in iFrame mode (for TinyMCE and CKEditor compatibility)
- Fix for TVs when which_editor != Redactor
- #103 Open in New Tab option when linking to Resources
- #20 Add MIGX Support
- #16 System Setting to load custom plugins


Redactor 1.1.2-pl
-----------------
Released on 2013-07-03

- Add missing cachebust from 1.1.1-pl.

Redactor 1.1.1-pl
-----------------
Released on 2013-07-03

- Update to Redactor 9.0.3, fixing among other things firefox issues with typing after selecting text, various cleanup bugs, switching between ul/ol tags. http://imperavi.com/redactor/log/
- Fix further issues with link editing.
- #46 Fix issues with iframe mode.

Redactor 1.1.0-pl
-----------------
Released on 2013-07-01

- Update to Redactor 9.0.2 fixing among other things pasting lists from Google Docs, inactive buttons, pasting in Chrome, link pasting and undo. http://imperavi.com/redactor/log/
- #40 Add browse feature for adding/linking to files + redactor.browse_files Setting to enable it
- #33 Add fullscreen plugin + redactor.buttonFullScreen Setting to enable it
- #55 Add redactor.displayImageNames Setting to display file names under images in Choose window
- #66 Add redactor.dynamicThumbs Setting to disable dynamic thumbnail (phpthumb)
- #50 Properly change/escape unsafe characters in uploads
- #56 Fix typeahead initialization on non-link modals
- #41 Show warning if no file exist in browsing location.
- #60 Add redactor.browse_path Setting to allow browsing elsewhere than uploads directory.
- #38 Add redactor.linkResource Setting to hide Resource tab in Link window
- #65 Fix Incorrect Link Options bug.
- #58 Combine and Minify JavaScript on frontend.
- #61 Cache Bust JavaScript.
- #62 Fixed broken manager pages with RedactorTV bug.
- #63 Moved Resource Tab to second position in insert link window
- French lexicon updated, partial Dutch and Czech added.

Redactor 1.0.3-pl
-----------------
Released on 2013-06-17

- Update to Redactor 9.0.1, fixing among other things backspace issues, link adding/editing. http://imperavi.com/redactor/log/
- #49 Make sure to use jQuery noConflict mode to make sure it plays nice with other possible jQuery instances.
- Fix wrong method (process instead of render) in TV Input Type.
- #53 Fix undefined on file upload bug.
- #51 Fixed broken links on dated files bug.
- #34 Moved Resource tab to first position.

Redactor 1.0.2-pl
-----------------
Released on 2013-06-05

- Fix additional issue with loading translations in non-English managers due to 9.0.0 changes.

Redactor 1.0.1-pl
-----------------
Released on 2013-06-05

- Fix issue with loading translations in non-English managers due to 9.0.0 changes.

Redactor 1.0.0-pl
-----------------
Released on 2013-06-05

- Fix ability to uninstall the package.
- #35, #36, #45 Update setting descriptions for Redactor 9.0.0 and to be more useful.
- #37 Change insert link text to "Insert/Edit link"
- #42 Add ability to disable the introtext displaying in resource typeahead.
- #43 Add ability to scroll in the resource type ahead
- Upgrade to Imperavi\'s Redactor 9.0.0

Redactor 0.9.3-pl
-----------------
Released on 2013-05-27

- Add French lexicon. Thanks @rtripault!
- #32 Add HTML5 tags to the default allowedTags setting.

Redactor 0.9.2-pl
-----------------
Released on 2013-05-27

- Fix bug where settings and other configuration were not properly passed to Redactor.
- Change default buttons to include separators.

Redactor 0.9.1-pl
-----------------
Released on 2013-05-24

- First released version of Redactor through modmore.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ecf973f608f39d7a45c6395654d4b06d',
      'native_key' => 'redactor',
      'filename' => 'modNamespace/659781fa18de4d0c6e161a7e5bc5b815.vehicle',
      'namespace' => 'redactor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b66176f3c9b308d402218c476389f5db',
      'native_key' => 'b66176f3c9b308d402218c476389f5db',
      'filename' => 'xPDOFileVehicle/8f230b8cef2d7fc2f51ea8999e81159c.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9cca11a9d454c7230c7dfcfdd785d528',
      'native_key' => '9cca11a9d454c7230c7dfcfdd785d528',
      'filename' => 'xPDOFileVehicle/b3ff927d5bb884b5a4620092ee0fc529.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'encryptedVehicle',
      'class' => 'modPlugin',
      'guid' => 'f96006ee5ac04d08134262185af86ae0',
      'native_key' => NULL,
      'filename' => 'modPlugin/e64af4ac3f742ca59b5f7df5e7c32233.vehicle',
      'namespace' => 'redactor',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bfe8109333cae2fc6d287671d562dcd',
      'native_key' => 'redactor.lang',
      'filename' => 'modSystemSetting/bce9a826f4024826dc419352a811035e.vehicle',
      'namespace' => 'redactor',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db24f7d7cf5b0f21f8b076bd4a85a7d2',
      'native_key' => 'redactor.direction',
      'filename' => 'modSystemSetting/ded463d5d88fd0ea7f574ad374b7466f.vehicle',
      'namespace' => 'redactor',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df8e144f2883130442107ab34823109f',
      'native_key' => 'redactor.buttons',
      'filename' => 'modSystemSetting/d199a00c7bc2ce617d583d14e7e27abc.vehicle',
      'namespace' => 'redactor',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3449f8cc053654ba14119fc1ab2b27e9',
      'native_key' => 'redactor.activeButtons',
      'filename' => 'modSystemSetting/83636422d9cc16ef17de3536a3e16311.vehicle',
      'namespace' => 'redactor',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08436b0b0d511ffc3955d0a476cd8eb3',
      'native_key' => 'redactor.activeButtonsStates',
      'filename' => 'modSystemSetting/cdc2cae2adc4e070f9c9f61fadc1f67a.vehicle',
      'namespace' => 'redactor',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b2b18dfdb2c5a9f108449d9e0419510',
      'native_key' => 'redactor.formattingTags',
      'filename' => 'modSystemSetting/f24ef77d8228dca08ee744a968e285eb.vehicle',
      'namespace' => 'redactor',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd714c4e3ca6ff312664ccdfc7323f4f0',
      'native_key' => 'redactor.buttonSource',
      'filename' => 'modSystemSetting/887b39a19c1d963ad23d121d485d31eb.vehicle',
      'namespace' => 'redactor',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc0d03c86918d4cb0128cd7469509241',
      'native_key' => 'redactor.buttonFullScreen',
      'filename' => 'modSystemSetting/18bf11f70252444ae99fb53fc685e05f.vehicle',
      'namespace' => 'redactor',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d6cd277fa9ca87b0591ef393cd8441f',
      'native_key' => 'redactor.css',
      'filename' => 'modSystemSetting/e4d7ce071e74f675a8a4c90b1f0bc903.vehicle',
      'namespace' => 'redactor',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '584418ce1a34ff4abe91310b81e58c1f',
      'native_key' => 'redactor.shortcuts',
      'filename' => 'modSystemSetting/585f1eb6d133352ec90d64338d0406e4.vehicle',
      'namespace' => 'redactor',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14278b22587ec2202dbdc73de179a3d5',
      'native_key' => 'redactor.cleanup',
      'filename' => 'modSystemSetting/4faadecea6a6e9edc337c275f49cf37e.vehicle',
      'namespace' => 'redactor',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbddc83d16cb45b81f26cada9d12fa74',
      'native_key' => 'redactor.convertLinks',
      'filename' => 'modSystemSetting/8bd10c71c8577af47a1477fd3fa8e97f.vehicle',
      'namespace' => 'redactor',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f2aa3ada1a24284c16af9c7c16aafa4',
      'native_key' => 'redactor.tabindex',
      'filename' => 'modSystemSetting/135c7bcdbfa1b8f62097144c72bbf7b6.vehicle',
      'namespace' => 'redactor',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c1f7ab9301c53df4888604e742d246b',
      'native_key' => 'redactor.minHeight',
      'filename' => 'modSystemSetting/e9bb7d26e038d0a889ddaa05e3b06ee5.vehicle',
      'namespace' => 'redactor',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57a3a5879e4c04064d8a6a7f5135465',
      'native_key' => 'redactor.colors',
      'filename' => 'modSystemSetting/40306db8dc20a28aac3ceed865538567.vehicle',
      'namespace' => 'redactor',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e3bba6e9740cefadd3d5aec0432b391',
      'native_key' => 'redactor.wym',
      'filename' => 'modSystemSetting/06d969fe0c65feff4883c8d027e8dcb0.vehicle',
      'namespace' => 'redactor',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd30178dfe45ab2667ed2ec6cae51ee88',
      'native_key' => 'redactor.linkProtocol',
      'filename' => 'modSystemSetting/1721dc2e8f6f39a09c0de158c0f6e531.vehicle',
      'namespace' => 'redactor',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39e97197f9a34a899a62a5cd00792f01',
      'native_key' => 'redactor.placeholder',
      'filename' => 'modSystemSetting/8a4c57a8c4c77d98e0ca6568e0a3c1ba.vehicle',
      'namespace' => 'redactor',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5452c3a827dff49cd468533d3fac2c1',
      'native_key' => 'redactor.linebreaks',
      'filename' => 'modSystemSetting/7824de5bb7a73080f68ba86fc7bd7327.vehicle',
      'namespace' => 'redactor',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0d58502bb1f3cc5807a4f5a59375430',
      'native_key' => 'redactor.allowedTags',
      'filename' => 'modSystemSetting/6f1f14123bb4c7c666a6eddc2fbe7c18.vehicle',
      'namespace' => 'redactor',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12e41196ae83ff443494318a5f62263c',
      'native_key' => 'redactor.deniedTags',
      'filename' => 'modSystemSetting/2f55288b270631afde776c3a8a265258.vehicle',
      'namespace' => 'redactor',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad56f53a4edde5956d8a9cda7ad157dc',
      'native_key' => 'redactor.linkEmail',
      'filename' => 'modSystemSetting/f000a11db20384678ecb58cb65e69dd8.vehicle',
      'namespace' => 'redactor',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f71b5327f3b3f8ad3bf12f72ebc43fe',
      'native_key' => 'redactor.linkAnchor',
      'filename' => 'modSystemSetting/fad2b24479949907af447f9e6601ee48.vehicle',
      'namespace' => 'redactor',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e9b44da9ae8f64d1049f0398cef3733',
      'native_key' => 'redactor.pastePlainText',
      'filename' => 'modSystemSetting/bc81f0ad18274c30cfd2801d2c41448c.vehicle',
      'namespace' => 'redactor',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa9614dfb2bdc0405b0d548c1d9e38ff',
      'native_key' => 'redactor.paragraphize',
      'filename' => 'modSystemSetting/a286a6538572f1a25d0a3b324345d170.vehicle',
      'namespace' => 'redactor',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '435909c5ac9bc6a57bbe1eb68d9400af',
      'native_key' => 'redactor.removeComments',
      'filename' => 'modSystemSetting/ed770cb0788dda7542ce7ea641b5a289.vehicle',
      'namespace' => 'redactor',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7259765ba98fdd40929b3972fe225a8',
      'native_key' => 'redactor.visual',
      'filename' => 'modSystemSetting/7fcfee5481bebba8e223dfdfe9448e64.vehicle',
      'namespace' => 'redactor',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea06d8fa66547005621bedbb9403c65b',
      'native_key' => 'redactor.marginFloatLeft',
      'filename' => 'modSystemSetting/54615aac60ede6e32985678c117563a5.vehicle',
      'namespace' => 'redactor',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac0c4df213c6a55f2cb0e56db4526174',
      'native_key' => 'redactor.marginFloatRight',
      'filename' => 'modSystemSetting/7a1f4b5fa9ece170f23006fc23cbaabf.vehicle',
      'namespace' => 'redactor',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcfaf3026c263b7b5a1fc0fcec350b0d',
      'native_key' => 'redactor.mediasource',
      'filename' => 'modSystemSetting/131753d339d30eb8762479a02697b16c.vehicle',
      'namespace' => 'redactor',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74567c696255012203204d1d646425b1',
      'native_key' => 'redactor.file_mediasource',
      'filename' => 'modSystemSetting/7e2137090bc2ceac1df91aec66e31edb.vehicle',
      'namespace' => 'redactor',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30e3f8b69e81cc33da4feb15bb2414f8',
      'native_key' => 'redactor.image_upload_path',
      'filename' => 'modSystemSetting/061ed6bb41c6e9150db5e46bc0298c53.vehicle',
      'namespace' => 'redactor',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f1c9308c130394d3f00af5112c97da6',
      'native_key' => 'redactor.image_browse_path',
      'filename' => 'modSystemSetting/5b600e4c04816223b13b4591dc6e47b1.vehicle',
      'namespace' => 'redactor',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76c64f1f719b761d2520aaa1785f5801',
      'native_key' => 'redactor.file_upload_path',
      'filename' => 'modSystemSetting/4cb4f87456ce06e41bae31cec4031004.vehicle',
      'namespace' => 'redactor',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e7da4a1fd870d719487fb0eb6ff9f1b',
      'native_key' => 'redactor.file_browse_path',
      'filename' => 'modSystemSetting/8ab5622a06826ed1824e2de44a308799.vehicle',
      'namespace' => 'redactor',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da4a2a60404c315736c541eaec7e1c06',
      'native_key' => 'redactor.browse_files',
      'filename' => 'modSystemSetting/ad26143a7ad97976d266acded8f18cb1.vehicle',
      'namespace' => 'redactor',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f29907196b555bafcc03dd355ac84b6f',
      'native_key' => 'redactor.date_images',
      'filename' => 'modSystemSetting/c2c6f41bec7afe94432e7e1911fd9473.vehicle',
      'namespace' => 'redactor',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc760613e758d12c8664b14fbb9b7309',
      'native_key' => 'redactor.date_files',
      'filename' => 'modSystemSetting/38661c75d6fc885a9ae6813e027a2c73.vehicle',
      'namespace' => 'redactor',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0468f297d06ae04340aacb46772aa036',
      'native_key' => 'redactor.typeahead.include_introtext',
      'filename' => 'modSystemSetting/a66bca9ed5a1d663928657155b971e3d.vehicle',
      'namespace' => 'redactor',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d8accedc397206932b1aca2fec5245b',
      'native_key' => 'redactor.prefetch_ttl',
      'filename' => 'modSystemSetting/a41b9cd7f4d3d18fd22b96ca4e41a0f5.vehicle',
      'namespace' => 'redactor',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30322f6b181e263a82eaa6eaa9f236ba',
      'native_key' => 'redactor.linkResource',
      'filename' => 'modSystemSetting/477ac7ab66122f846ab5eeb7aed35547.vehicle',
      'namespace' => 'redactor',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cde1c88339bb13dbbe77b27e7c4c3761',
      'native_key' => 'redactor.cleanFileNames',
      'filename' => 'modSystemSetting/1f37a810a7085a42e24d5e4f2e2a4ff1.vehicle',
      'namespace' => 'redactor',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93ed60f574ab6beaf726bf7cbeaf2894',
      'native_key' => 'redactor.dynamicThumbs',
      'filename' => 'modSystemSetting/2bc295f6bb445a2301ed0d683349df89.vehicle',
      'namespace' => 'redactor',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81f4a5a91555041b7f723638177c8513',
      'native_key' => 'redactor.clipsJson',
      'filename' => 'modSystemSetting/1b07985c8756399e2f37d246c7f1af0e.vehicle',
      'namespace' => 'redactor',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '238e84e73c720e2701d5084ffd4e799e',
      'native_key' => 'redactor.additionalPlugins',
      'filename' => 'modSystemSetting/60151a60e1fd1df20dba20a10b2593b4.vehicle',
      'namespace' => 'redactor',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e08b2c1e0a7b4a63c938622aef05286',
      'native_key' => 'redactor.dragUpload',
      'filename' => 'modSystemSetting/2e385361d9cde74082f81e011f3573f6.vehicle',
      'namespace' => 'redactor',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76af3b45b2716c3cae0c1d25325e6f3a',
      'native_key' => 'redactor.convertImageLinks',
      'filename' => 'modSystemSetting/c6c726754e947e7ea111ba7ae150313d.vehicle',
      'namespace' => 'redactor',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab907f54dee2c99111a466f2e43e2cdc',
      'native_key' => 'redactor.convertVideoLinks',
      'filename' => 'modSystemSetting/96a042f2288adaac1897bd3e79923886.vehicle',
      'namespace' => 'redactor',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd78f3609f63b1c9b1a4146152416bea',
      'native_key' => 'redactor.tabAsSpaces',
      'filename' => 'modSystemSetting/94a1ada5895addc59a1af75b67f4bf72.vehicle',
      'namespace' => 'redactor',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82d4d392795ebbf3468f39015b680d33',
      'native_key' => 'redactor.removeEmptyTags',
      'filename' => 'modSystemSetting/99112cc3a66d60d18d8df168de6ca480.vehicle',
      'namespace' => 'redactor',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b98481a5322774791f146c6d7ea07b33',
      'native_key' => 'redactor.sanitizePattern',
      'filename' => 'modSystemSetting/9bdfa382ce1847b4f2700e5388d2af92.vehicle',
      'namespace' => 'redactor',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2d695480bf3a0f8197ed05e51fd28ae',
      'native_key' => 'redactor.sanitizeReplace',
      'filename' => 'modSystemSetting/7baafa4d6632096dd2171c93dc963fd6.vehicle',
      'namespace' => 'redactor',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae7c429a2b93c3a86c797b29638eff7e',
      'native_key' => 'redactor.linkSize',
      'filename' => 'modSystemSetting/b1c591c5807a4f74d4daa3bbc5b0245e.vehicle',
      'namespace' => 'redactor',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8040e622ad2761e2a36dad10bc865988',
      'native_key' => 'redactor.advAttrib',
      'filename' => 'modSystemSetting/3f7cded4fa5434b7032038e73db107e6.vehicle',
      'namespace' => 'redactor',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e035d91d4dbc17bf85cee1ec2d79e9bd',
      'native_key' => 'redactor.linkNofollow',
      'filename' => 'modSystemSetting/c34dd41751f28c59b4c566760571f393.vehicle',
      'namespace' => 'redactor',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41e84e0924368fbeafe68b5b24ed1da2',
      'native_key' => 'redactor.typewriter',
      'filename' => 'modSystemSetting/f5bd7caf9d1df0463719f3ef36e8beb5.vehicle',
      'namespace' => 'redactor',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9092cc289803cea0c88c32de9721d54',
      'native_key' => 'redactor.buttonsHideOnMobile',
      'filename' => 'modSystemSetting/ade4e1a266e077dd2dea4eb14bbadf5d.vehicle',
      'namespace' => 'redactor',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f16e30be22bee839bb319341f622c104',
      'native_key' => 'redactor.toolbarOverflow',
      'filename' => 'modSystemSetting/f2366fcc20e97c6297c67d0ca888e51e.vehicle',
      'namespace' => 'redactor',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bc14ea7eae61a6a2df57268c6bb55db',
      'native_key' => 'redactor.imageTabLink',
      'filename' => 'modSystemSetting/c8226d4ddc6543c0a1f0c5d282192732.vehicle',
      'namespace' => 'redactor',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb6b1531d394afc14a3f943d2e53a071',
      'native_key' => 'redactor.cleanSpaces',
      'filename' => 'modSystemSetting/4293f926f207c17e2c32d05c077e178d.vehicle',
      'namespace' => 'redactor',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a646c0e111127cc55e750a8a484eef16',
      'native_key' => 'redactor.predefinedLinks',
      'filename' => 'modSystemSetting/977d18e985da4a9f7fd6e816cf0ec156.vehicle',
      'namespace' => 'redactor',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5460bab10e81843cdabee2f38dec7ae4',
      'native_key' => 'redactor.shortcutsAdd',
      'filename' => 'modSystemSetting/c4a115deb6ee6d60cac3f679369ca85a.vehicle',
      'namespace' => 'redactor',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cbe7b64bcad2cd997a2d8e4289c56ce',
      'native_key' => 'redactor.commemorateRebecca',
      'filename' => 'modSystemSetting/bbebccdf8de92118a2b2f075a3686c8c.vehicle',
      'namespace' => 'redactor',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3afd11e8d03b4476b05f32469b7f1a5',
      'native_key' => 'redactor.toolbarFixed',
      'filename' => 'modSystemSetting/0f01f6e20a026c329e95dca56e8e7844.vehicle',
      'namespace' => 'redactor',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34e989ff885d03fa3c079957dfbf65f8',
      'native_key' => 'redactor.focus',
      'filename' => 'modSystemSetting/d15cce3a4dfd2218b2829a10df4d53b8.vehicle',
      'namespace' => 'redactor',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de1498c0e15cbeb94819bcd72840bda9',
      'native_key' => 'redactor.focusEnd',
      'filename' => 'modSystemSetting/177743a08d37e5c19f2863b2bc58edf9.vehicle',
      'namespace' => 'redactor',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0438af61d65e0ad501898b52202b94d7',
      'native_key' => 'redactor.scrollTarget',
      'filename' => 'modSystemSetting/581b6be4c83d4def1b315dfe005cb14d.vehicle',
      'namespace' => 'redactor',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f016ecaec50f1b62f9d6f0051c27d9c',
      'native_key' => 'redactor.enterKey',
      'filename' => 'modSystemSetting/95180fc3b277d0b5ff49580706598a06.vehicle',
      'namespace' => 'redactor',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5749556ad4bf03125bf46592679205ee',
      'native_key' => 'redactor.cleanStyleOnEnter',
      'filename' => 'modSystemSetting/f26470b8059708fb48c8cb7602221a52.vehicle',
      'namespace' => 'redactor',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dcdc4d065767efd07d1b292e07eac3d',
      'native_key' => 'redactor.linkTooltip',
      'filename' => 'modSystemSetting/dbac38deb0f317d4b8651dfceb841c71.vehicle',
      'namespace' => 'redactor',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '046b97d37fa3de557ad3894cde1d09ae',
      'native_key' => 'redactor.imageEditable',
      'filename' => 'modSystemSetting/d1a48d92df1946586005596eb9d42329.vehicle',
      'namespace' => 'redactor',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87438d64b38422ebd11878a365b57ed5',
      'native_key' => 'redactor.imageResizable',
      'filename' => 'modSystemSetting/0b0721718a33a9e7c8cff7d60a912eca.vehicle',
      'namespace' => 'redactor',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08ef0cc092f9c03e7fe189533b5709cc',
      'native_key' => 'redactor.imageLink',
      'filename' => 'modSystemSetting/7ad490c4e92e0315525d9c86e71202b5.vehicle',
      'namespace' => 'redactor',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1804a2dfbec84aad6a72ee67c970f02f',
      'native_key' => 'redactor.imagePosition',
      'filename' => 'modSystemSetting/8464ef158fa71549307b8a96c63f1482.vehicle',
      'namespace' => 'redactor',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38f98054c03204c45669bf536b2c0761',
      'native_key' => 'redactor.buttonsHide',
      'filename' => 'modSystemSetting/5e4d98ef8c9ba05d7d6ded037718faa5.vehicle',
      'namespace' => 'redactor',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ec94443eddf32c0482397355478abdd',
      'native_key' => 'redactor.formattingAdd',
      'filename' => 'modSystemSetting/931e8d2cd059dc216ae8b3d11bd6aa1d.vehicle',
      'namespace' => 'redactor',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '355bab5a9720c21fbdfff8e82e131bd0',
      'native_key' => 'redactor.tabifier',
      'filename' => 'modSystemSetting/6afc1c747b879595ba3785771f879ea7.vehicle',
      'namespace' => 'redactor',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '188c031bf483df8d35b204860bd4e9e4',
      'native_key' => 'redactor.replaceTags',
      'filename' => 'modSystemSetting/8571a30881d81dc2907e5b864c10d01e.vehicle',
      'namespace' => 'redactor',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '651d128fcf7de2c87cf991c36f9f46e4',
      'native_key' => 'redactor.replaceStyles',
      'filename' => 'modSystemSetting/b54faf32ecd512a8531a1b5b58c2eed8.vehicle',
      'namespace' => 'redactor',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0953b01ebf03591919d01b99a0db602e',
      'native_key' => 'redactor.removeDataAttr',
      'filename' => 'modSystemSetting/babcee6067cc8a899986771da2edb43f.vehicle',
      'namespace' => 'redactor',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aba169908abba015788e9c7e7de49dca',
      'native_key' => 'redactor.removeAttr',
      'filename' => 'modSystemSetting/d113883e0c313046d8815f0f76e4069d.vehicle',
      'namespace' => 'redactor',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd39d5460da5affc2584e8fbd764c836d',
      'native_key' => 'redactor.allowedAttr',
      'filename' => 'modSystemSetting/422dbdadc148db3a1aa9e6952d3943bc.vehicle',
      'namespace' => 'redactor',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cb1cbde470e837e318c190a1d5d0318',
      'native_key' => 'redactor.dragImageUpload',
      'filename' => 'modSystemSetting/58729ebdfc3ac0e8858459ff6edd86c5.vehicle',
      'namespace' => 'redactor',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be55ce124205252b52004e4d1e9f0314',
      'native_key' => 'redactor.dragFileUpload',
      'filename' => 'modSystemSetting/09dd528b8691f129554ea6601d6d8e83.vehicle',
      'namespace' => 'redactor',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '094b93d8e2561af973afb4c3abde7b95',
      'native_key' => 'redactor.replaceDivs',
      'filename' => 'modSystemSetting/38597d5962317aab1ffd6ad03f36e233.vehicle',
      'namespace' => 'redactor',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa7834d04b26c5a6c006699d66665c50',
      'native_key' => 'redactor.preSpaces',
      'filename' => 'modSystemSetting/976c745f9037e5a2933b12056edd0fd8.vehicle',
      'namespace' => 'redactor',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f01759a89a56d59f5d2692cdba3bab25',
      'native_key' => 'redactor.parse_parent_path',
      'filename' => 'modSystemSetting/d45cf7879445c0cfd3cbc0ef40692d64.vehicle',
      'namespace' => 'redactor',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94cb24198ced39e40111521e939183fc',
      'native_key' => 'redactor.increment_file_names',
      'filename' => 'modSystemSetting/c73fa5e2ca64209b18f5068765239baa.vehicle',
      'namespace' => 'redactor',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bea3224be6d9a5a3cdf4c93f897d25ef',
      'native_key' => 'redactor.parse_parent_path_height',
      'filename' => 'modSystemSetting/a033d477ae0200f63521485e22c103c9.vehicle',
      'namespace' => 'redactor',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb5ac630b5d21c63ff218ea9be96dc47',
      'native_key' => 'redactor.baseurls_mode',
      'filename' => 'modSystemSetting/33a6b4565d4fce4d67267183abb57dc9.vehicle',
      'namespace' => 'redactor',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8617ec95e8497c6c381f646ad62594a5',
      'native_key' => 'redactor.showDimensionsOnResize',
      'filename' => 'modSystemSetting/344b99075c77de20df80a970acd325ff.vehicle',
      'namespace' => 'redactor',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '985b4e05d205d38f83acdbbc40f1ddae',
      'native_key' => 'redactor.plugin_counter',
      'filename' => 'modSystemSetting/c95b6639a36be83d895276591430211d.vehicle',
      'namespace' => 'redactor',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a69e41b4b78589c1be41ba9369387e7',
      'native_key' => 'redactor.plugin_fontcolor',
      'filename' => 'modSystemSetting/690aab4ae09b96790de77f3c8a4e75b2.vehicle',
      'namespace' => 'redactor',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6e228b9f1c9bb91155604e982c011f2',
      'native_key' => 'redactor.plugin_fontfamily',
      'filename' => 'modSystemSetting/171cf5cf5b89190aeb4c0ed261bae24c.vehicle',
      'namespace' => 'redactor',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c736d52719553ad87e595c782b27a9e',
      'native_key' => 'redactor.plugin_fontsize',
      'filename' => 'modSystemSetting/1619b3fcc1244d5c9cfe5a48217765b0.vehicle',
      'namespace' => 'redactor',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '984df714685420856f54083db2bb434d',
      'native_key' => 'redactor.plugin_limiter',
      'filename' => 'modSystemSetting/9fbb209f1aa724a4149d8637aa0e4afe.vehicle',
      'namespace' => 'redactor',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f030fff873528f8de54b6b7ff2881bc',
      'native_key' => 'redactor.plugin_table',
      'filename' => 'modSystemSetting/4c7cc4fe532ed9d226c2f0c5134fdc28.vehicle',
      'namespace' => 'redactor',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25d4cdf0aa4b8a664ed5c0ab9bad6b0e',
      'native_key' => 'redactor.plugin_textdirection',
      'filename' => 'modSystemSetting/0ed9a5c58828fb7e48d90cec9f39d195.vehicle',
      'namespace' => 'redactor',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76ebc00621364fb82bc0392d80021126',
      'native_key' => 'redactor.plugin_video',
      'filename' => 'modSystemSetting/441f5efe438266e5b3bd02d219405682.vehicle',
      'namespace' => 'redactor',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '897924aa3e2f2f31fb131c1d24159e56',
      'native_key' => 'redactor.plugin_replacer',
      'filename' => 'modSystemSetting/4b7c38aec35cefda3efaf1f0564c61c2.vehicle',
      'namespace' => 'redactor',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df8cd22e20c28b04b7cadd6eb55c9bdd',
      'native_key' => 'redactor.plugin_replacer_button',
      'filename' => 'modSystemSetting/d1ea5285b24bd991961c942829f0c894.vehicle',
      'namespace' => 'redactor',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'add6b4a696972f207f7efe6e80eed0f3',
      'native_key' => 'redactor.plugin_syntax',
      'filename' => 'modSystemSetting/3a9d080e91607221d11b71d2509d887e.vehicle',
      'namespace' => 'redactor',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac6173546752e44ea8898bd7a784a76e',
      'native_key' => 'redactor.plugin_speek',
      'filename' => 'modSystemSetting/c975a3588801f9e75bbea15626bbde56.vehicle',
      'namespace' => 'redactor',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3068fc4dfc016d7c03b39d4f65604be',
      'native_key' => 'redactor.plugin_contrast',
      'filename' => 'modSystemSetting/9614c5f4474a9c7d64996e2c64b1bb3d.vehicle',
      'namespace' => 'redactor',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4026a420c7bd7f8cdf4de93e678af5dc',
      'native_key' => 'redactor.plugin_eureka',
      'filename' => 'modSystemSetting/fb1b54bed43c7366f735d8759f90a5a3.vehicle',
      'namespace' => 'redactor',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d127358c52cc841d195bac5879b4ce0',
      'native_key' => 'redactor.plugin_eureka_shivie9',
      'filename' => 'modSystemSetting/70aaf1b7d133a65124707d9094a4f7da.vehicle',
      'namespace' => 'redactor',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d83effc37aa68c1e439a31fe369d4d1',
      'native_key' => 'redactor.eurekaUpload',
      'filename' => 'modSystemSetting/e93f99e7283e4b86fc773426d9ab02c7.vehicle',
      'namespace' => 'redactor',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7872fba0bc4f1b8fbd2e8bc65e31971',
      'native_key' => 'redactor.initial_directory_depth',
      'filename' => 'modSystemSetting/46b11a4eb933dca93fc6467da7a52b9f.vehicle',
      'namespace' => 'redactor',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '539bfea25a43b106839836362d7b50c0',
      'native_key' => 'redactor.plugin_zoom',
      'filename' => 'modSystemSetting/8944253afcf632711805edcb555fb872.vehicle',
      'namespace' => 'redactor',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '399550d5fdbaccef5d04ba3baed0362d',
      'native_key' => 'redactor.plugin_download',
      'filename' => 'modSystemSetting/014241b45468626fe0dfefee0715c253.vehicle',
      'namespace' => 'redactor',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8559a3ef4013d576b092e97816918e35',
      'native_key' => 'redactor.plugin_imagepx',
      'filename' => 'modSystemSetting/7b248d75bfdc4372035fb61a5c86b905.vehicle',
      'namespace' => 'redactor',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7918f49f5b7f9024469ff0843ce404c9',
      'native_key' => 'redactor.plugin_imageurl',
      'filename' => 'modSystemSetting/76249164c3e823622fabcef47d04444f.vehicle',
      'namespace' => 'redactor',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f800e83e9b97b33c795c63f8d437394d',
      'native_key' => 'redactor.plugin_breadcrumb',
      'filename' => 'modSystemSetting/759f099b8cc86e789da181dd8f598902.vehicle',
      'namespace' => 'redactor',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e83ebea4a110e2d1d0e745bfad4b8df',
      'native_key' => 'redactor.plugin_norphan',
      'filename' => 'modSystemSetting/9771abdfc7bb6c82ffd4214539d7260d.vehicle',
      'namespace' => 'redactor',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1426a490c027e19940cb6639c7f5d1a2',
      'native_key' => 'redactor.plugin_baseurls',
      'filename' => 'modSystemSetting/cf2844ff88ed0dc335a9f1716689432b.vehicle',
      'namespace' => 'redactor',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8b9e19ef3397a86e80904ac448b7105',
      'native_key' => 'redactor.textexpander',
      'filename' => 'modSystemSetting/a3037076a378e5cd9ad2cc81edee1b32.vehicle',
      'namespace' => 'redactor',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e65ebbdd9e51fb3af1f4d60e4905b2b4',
      'native_key' => 'redactor.speechPitch',
      'filename' => 'modSystemSetting/97fb3ac3f3250fce20fecf49a673e44f.vehicle',
      'namespace' => 'redactor',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a84bc5c7df5f54259d5cd4781c43080',
      'native_key' => 'redactor.speechRate',
      'filename' => 'modSystemSetting/c530adafbd4f63b5c2514e4e9eb1d2c3.vehicle',
      'namespace' => 'redactor',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00bd3b43fd7eda701fa749a66c0c89f9',
      'native_key' => 'redactor.speechVolume',
      'filename' => 'modSystemSetting/4e7c55489ec36aa4c7a69248dbefb915.vehicle',
      'namespace' => 'redactor',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69be1ab66586a97d6238c6eb8fcfcbe0',
      'native_key' => 'redactor.speechVoice',
      'filename' => 'modSystemSetting/97498fcdad40d2ecb7085cf573531d70.vehicle',
      'namespace' => 'redactor',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4dfc09a0dd804cd2e8ab7580d6c3ec8',
      'native_key' => 'redactor.counterWPM',
      'filename' => 'modSystemSetting/8a53c717ce4228365ea59b542384439c.vehicle',
      'namespace' => 'redactor',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe2e2324e9c1105fa8502a76cd52e36e',
      'native_key' => 'redactor.codemirror',
      'filename' => 'modSystemSetting/f51fce6d6f740140fb673e3803769531.vehicle',
      'namespace' => 'redactor',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aab507b7f919d24a68209c04d61ed10',
      'native_key' => 'redactor.plugin_uploadcare',
      'filename' => 'modSystemSetting/182abfe53111c0fdb8bfa6cb968ef877.vehicle',
      'namespace' => 'redactor',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2f04ff3c082fe53279d6d61dd5be371',
      'native_key' => 'redactor.uploadcare_pub_key',
      'filename' => 'modSystemSetting/ed0b477b592113f13b9693fc27db52ab.vehicle',
      'namespace' => 'redactor',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f426c25ae0160e75117408c1e5800e4',
      'native_key' => 'redactor.uploadcare_locale',
      'filename' => 'modSystemSetting/4d95c99e041568781cb9b08abd8a6502.vehicle',
      'namespace' => 'redactor',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c590203482277aac3472afba3c86332c',
      'native_key' => 'redactor.uploadcare_crop',
      'filename' => 'modSystemSetting/39dd8180ecba4aa68c3a52f033939788.vehicle',
      'namespace' => 'redactor',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2464fbe11ec8e2b6bf8e17541c99a4dc',
      'native_key' => 'redactor.uploadcare_tabs',
      'filename' => 'modSystemSetting/e981d50b7f376b46509e00a1a0546e80.vehicle',
      'namespace' => 'redactor',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77496f8f0c6c5150d5492c02849a6ee3',
      'native_key' => 'redactor.loadIntrotext',
      'filename' => 'modSystemSetting/5b088dbc2d452e152934abe5758f02a4.vehicle',
      'namespace' => 'redactor',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6e19d632703f5cf15555817768320d9',
      'native_key' => 'redactor.limiter',
      'filename' => 'modSystemSetting/6d4752ece245ca021c4880ace76ef32f.vehicle',
      'namespace' => 'redactor',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '29da1ff0c1a4f231c99583a65fbcb79a',
      'native_key' => '29da1ff0c1a4f231c99583a65fbcb79a',
      'filename' => 'xPDOScriptVehicle/59e8eb5b6813eaf7845c9458a948147e.vehicle',
      'namespace' => 'redactor',
    ),
  ),
);