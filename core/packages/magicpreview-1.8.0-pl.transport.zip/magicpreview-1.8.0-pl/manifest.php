<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 Mark Hamstra Web Development <support@modmore.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
',
    'readme' => 'MagicPreview for MODX
=====================

MagicPreview adds a _Magical_ Preview button to the MODX resource editor that lets you see
exactly how your page will look -- without saving. Edit your content, click Preview,
and instantly see a live, fully rendered preview of your changes.

It works with MODX 2.x and 3.x (PHP 7.4+), supports custom resource types
(Collections, Articles, etc.), and integrates with rich text editors and
ContentBlocks automatically.


Preview Modes
-------------

Choose how you want to preview your work:

- New Window: Opens the preview in a separate browser window (default).
- Panel: Shows the preview in an inline side panel right next to the editor, so you
  can edit and preview simultaneously without switching windows.

The panel has two layout options:

- Overlay: The panel slides in from the right and floats on top of the editor.
- On Page: The editor shrinks to make room for a permanent preview column alongside
  it.

Both the preview mode and panel layout can be overridden per resource from the
resource\'s Settings tab, allowing you to use different configurations for different
parts of your site.


Responsive Breakpoints
----------------------

Preview your page at different screen widths with one click. Four breakpoint buttons
are available in both the preview window and the panel toolbar:

- Full (100% width)
- Desktop (default: 1280px)
- Tablet (default: 768px)
- Mobile (default: 320px)

Each breakpoint width is configurable via system settings. Width transitions are
smoothly animated.


Auto-Refresh
------------

When using the panel, MagicPreview can automatically refresh the preview at a
configurable interval (default: every 5 seconds). The preview only reloads when your
form data has actually changed, so it is efficient and unobtrusive. Set the interval
to 0 to disable auto-refresh. An open preview also reloads when the resource is
saved.


Draft Save & Restore
--------------------

Working on a page but not ready to publish? Use the Save Draft button (or press
Ctrl+Shift+S / Cmd+Shift+S) to save your current edits as a draft. Drafts are stored
per resource and per user, so your work is private and won\'t interfere with other
editors.

Drafts are kept in the database, so they survive cache clears -- and saving the
resource itself -- until you restore or discard them.

When you return to a resource that has a saved draft, a notification banner lets you
view, share, restore or discard it. Restoring a draft reloads the page with all your
previous edits filled in -- including template variables and extras data.

Draft expiry is configurable; by default drafts are kept until restored or manually
discarded.


Share Draft Links
-----------------

Need feedback from someone without manager access? Drafts can be shared via public
links, so a client or colleague can review work in progress right in their browser.
A link always shows the latest saved draft, can be given a label and its own expiry,
and can be revoked at any time. Links stop working once the draft is discarded.


Click to Field (Experimental)
-----------------------------

When the click_to_field setting is enabled, clicking a field in the preview panel
scrolls the resource form to the corresponding field and briefly highlights it.

ContentBlocks fields are marked automatically. Core resource fields and TVs are
marked in your template with the mpField snippet - see "Click to Field" below.

Disabled by default.


Controlling Where Preview Appears
----------------------------------

The Preview button can be limited to (or excluded from) resources using certain
templates via a block list or allow list in the system settings. Individual
resources can also force it on or off from their Settings tab.


Drag-to-Resize
---------------

In panel mode, drag the left edge of the panel to resize it to your preferred width.
Your chosen width is remembered across page loads.


Flicker-Free Updates
--------------------

The panel uses a double-buffered iframe technique: new content loads in a hidden
iframe behind the scenes, and only swaps in once it is fully rendered. Your scroll
position is preserved across refreshes, so you never lose your place.


Keyboard Shortcuts
------------------

- Ctrl+P / Cmd+P: Trigger a preview
- Ctrl+Shift+S / Cmd+Shift+S: Save a draft


Customisation
-------------

MagicPreview is designed to work out of the box, but offers several customisation
options via system settings:

- Custom preview template: Override the Smarty template used for the preview window.
- Custom preview CSS: Load an additional CSS file in the preview window.
- Configurable breakpoint widths for desktop, tablet, and mobile.
- Configurable button icons: Replace the default Save Draft and View button icons
  with any FontAwesome icon class.
- Auto-refresh interval: Adjust or disable the automatic refresh timer.
- Click to field: Enable the experimental click-to-field feature (disabled by default).
- Draft TTL: Control how long drafts are kept before expiring.
- Share link lifetime: Set the default expiry for share links.
- Template filter: Choose which templates show the Preview button.


Third-Party Integration
-----------------------

MagicPreview fires a custom system event (OnResourceMagicPreview) during the preview
process, allowing other extras to modify the resource data before it is rendered. This
is used by extras like VersionX to preview version history without saving.

A public JavaScript API is also available for extras that need to open, close, or
interact with the preview programmatically.


Click to Field
--------------

With the magicpreview.click_to_field system setting enabled, clicking part of the
preview panel scrolls the resource form to the matching field. Previews opened in a
new window, including a draft\'s View link, show the page without click targets.

You can now mark which fields should use this feature.

Core resource fields and TVs, with the mpField snippet:

    <h1 [[!mpField? &name=`pagetitle`]] class="title">[[*pagetitle]]</h1>
    <div [[!mpField? &name=`mytv`]] class="mytv">[[*mytv]]</div>

Call it uncached (with the !). An uncached call is evaluated on every page render,
so an extra that caches rendered output - getCache, for example - can never store
the attributes in its cache.

With pdoTools/Fenom, any of these work:

    <h1 {\'pagetitle\' | mpField}>{$_modx->resource.pagetitle}</h1>
    <h1 {\'mpField\' | snippet: [\'name\' => \'pagetitle\']}>...</h1>

ContentBlocks fields are wrapped automatically in a preview and need no changes. To
place the attributes on your own element instead, put the placeholder inside its
opening tag - the wrapper is then skipped for that field:

    <h2 [[+mpClickToFieldAttributes]] class="heading">[[+value]]</h2>

This works in templates typed into the field\'s Template setting, and in @FILE and
@PDO_FILE templates. A @PDO_FILE template written in Fenom uses the same MODX-style tag, which
pdoTools processes alongside the Fenom syntax:

    <{$level} [[+mpClickToFieldAttributes]] class="headline">{$value}</{$level}>

@PDO_FILE fields are never wrapped automatically, so the placeholder is the only way
to make them clickable. Fields using @CHUNK templates cannot be marked yet.

The snippet and placeholder produce nothing outside the preview panel, so they are
safe to leave in live templates and do not appear on public share links. Outside a
preview the ContentBlocks placeholder resolves to nothing as the field is parsed, so
it is not stored in the resource content either. If in doubt, load the live page and
search its source for data-magicpreview: there should be no matches.


Support & Documentation
-----------------------

Full documentation is available at: https://www.modmore.com/extras/magicpreview/
',
    'changelog' => 'MagicPreview 1.8.0-pl
---------------------
Released on 2026-09-25

- Fix click_to_field breaking Fenom (and any other custom parser) output in previews. MagicPreview no longer replaces the MODX parser during a preview render. (#55)
- BREAKING: core resource fields and TVs are no longer marked clickable automatically. Mark them in your template with the new mpField snippet; see the readme for examples.
- Add mpField snippet, usable as a MODX tag or a Fenom modifier ({\'pagetitle\'|mpField})
- Add [[+mpClickToFieldAttributes]] placeholder for ContentBlocks field templates, so the attributes can go on your own element instead of an added wrapper. Works in inline, @FILE and @PDO_FILE templates, including Fenom ones, and gives @PDO_FILE fields a click target for the first time.
- Click to field now applies only to the preview panel. Previews in a new window, and a draft\'s View link, show the page without click targets.
- Fix click-to-field markers being stored in drafts and shown on public share links when click_to_field is on (since 1.7.0). Drafts saved by 1.7.x are cleaned automatically the first time they are read.
- Fix click-to-field markup being written to the live page\'s cache when a preview URL was opened after its preview data had expired, or when a preview was forwarded to another page such as the error page (since 1.7.0)

MagicPreview 1.7.1-pl
---------------------
Released on 2026-07-10

- Fix drafts and shares database tables not being created by the package installer (broken in 1.7.0 — upgrading creates the missing tables)

MagicPreview 1.7.0-pl
---------------------
Released on 2026-07-10

- Auto-reload preview on resource save
- Collapse MODX 3 resource sidebar when on-page preview is visible.
- Add view button to draft panel
- Add share button to draft panel
- Add token-protected endpoint for sharing drafts
- Allow multiple shares of the same draft each with unique tokens
- Add windows/grid/form for managing shares
- Enable/disable previews on resources based on template id set by new system settings
- Enable/disable previews based on new per resource settings
- Layout spacing tweaks
- Add click-to-field (experimental): clicking a field in the preview scrolls the resource form to that field. Supports core resource fields, TVs and ContentBlocks.

MagicPreview 1.6.0-pl
---------------------
Released on 2026-03-28

- Add inline side panel preview mode with overlay and on-page layouts
- Add per-resource overrides for preview mode and panel layout
- Add auto-refresh with configurable interval
- Add drag-to-resize for the panel
- Add draft save/restore with Ctrl+Shift+S shortcut
- Add configurable draft TTL
- Add configurable icons for Save Draft and View buttons
- Add Ctrl+P keyboard shortcut for preview
- Add Ctrl+Shift+S keyboard shortcut for saving a draft
- Add panel state persistence

MagicPreview 1.5.1-pl
---------------------
Released on 2025-04-11

- Fix placeholders showing the cached value instead of the change due to in-memory element cache not being cleared [79144aa]

MagicPreview 1.5.0-pl
---------------------
Released on 2025-03-14

- Add support for VersionX so version deltas of resources can be previewed before reverting to them [#37]

MagicPreview 1.4.1-pl
---------------------
Released on 2024-12-13

- Fixed a rendering issue with the new merged buttons (thanks to @jenswittmann) [#34]

MagicPreview 1.4.0-pl
---------------------
Released on 2024-11-29

- Group MagicPreview\'s Preview button with the standard MODX View resource button for a more compact view (thanks to @jenswittmann) [#31]
- Add magicpreview.custom_preview_css and magicpreview.custom_preview_tpl to enable customising the HTML and CSS in the preview (thanks to @jenswittmann) [#32]

MagicPreview 1.3.0-pl
---------------------
Released on 2022-11-19

- Make preview width breakpoints configurable via system settings (thanks to @Peeet93) [#28]

MagicPreview 1.2.4-pl
---------------------
Released on 2022-10-06

- Fix preview button not showing on Collections, Articles and Location custom resources.

MagicPreview 1.2.3-pl
---------------------
Released on 2022-07-15

- CSS tweaks to cater for longer pagetitles in preview title bar. [8c80d43]

MagicPreview 1.2.2-pl
---------------------
Released on 2022-06-02

- Fixed a fatal error that would sometimes occur when loading a preview (thanks to @pbowyer) [#24]
- Replaced the title link with a close button.

MagicPreview 1.2.1-pl
---------------------
Released on 2021-11-29

- Make loading of required processor files more efficient by using the full path. [#17]

MagicPreview 1.2.0-pl
---------------------
Released on 2021-11-19

- Introduce compatibility for MODX 3.

MagicPreview 1.1.1-pl
---------------------
Released on 2021-11-16

- Make sure OnResourceMagicPreview event has a service set

MagicPreview 1.1.0-pl
---------------------
Released on 2021-10-02

- Fix view button not working after clicking on the preview button
- Add OnResourceMagicPreview event so other extras such as ContentBlocks can hook in when using the preview button.
- Fix system fonts used in the preview, did not apply on Windows (among others)

MagicPreview 1.0.1-pl
---------------------
Released on 2018-12-18

- Add loading animation [#6]
- Rewrite CSS to BEM standards, reduce header size [#5]
- Add version-based cache busting to js and css files

MagicPreview 1.0.0-pl
---------------------
Released on 2018-12-17

- First magical release!
',
    'setup-options' => 'magicpreview-1.8.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c672109377bdc5f78689906eeed43d1d',
      'native_key' => 'magicpreview',
      'filename' => 'modNamespace/066bbd8612b5a6585beaed320213e6d7.vehicle',
      'namespace' => 'magicpreview',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7f4a9be7042b805f3bac2f9c96e08765',
      'native_key' => '7f4a9be7042b805f3bac2f9c96e08765',
      'filename' => 'xPDOFileVehicle/5cb0e7eacc808a8816f9864c753bb306.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a6ad9f31c0320b8ad1c9ae623b60931a',
      'native_key' => 'a6ad9f31c0320b8ad1c9ae623b60931a',
      'filename' => 'xPDOFileVehicle/c4ffa015cf4c0c80bd64f8fe4b2bf049.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '752b29adb6162de094b10574735a68eb',
      'native_key' => 'magicpreview.breakpoint_desktop',
      'filename' => 'modSystemSetting/a427eded4455ff111aeaf199331865e8.vehicle',
      'namespace' => 'magicpreview',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16f52c2611004b7d7c77f7361315207a',
      'native_key' => 'magicpreview.breakpoint_tablet',
      'filename' => 'modSystemSetting/616abf3e3006fd193fcc01ea3c29cff8.vehicle',
      'namespace' => 'magicpreview',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '546624cfba72fa3dcefe43106db12b2c',
      'native_key' => 'magicpreview.breakpoint_mobile',
      'filename' => 'modSystemSetting/25b9a4e0642a2815f8c641b16656fd9f.vehicle',
      'namespace' => 'magicpreview',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d5bd07ee38fb2e632662260318cd59c',
      'native_key' => 'magicpreview.custom_preview_tpl',
      'filename' => 'modSystemSetting/d0ac44140b5fa1cda52b47957ff67835.vehicle',
      'namespace' => 'magicpreview',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4024eedcdbc43d6f7a43e35ac3818fff',
      'native_key' => 'magicpreview.custom_preview_css',
      'filename' => 'modSystemSetting/3632f1e742cdd48e3877e3a143d3981d.vehicle',
      'namespace' => 'magicpreview',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46ca5fd9b04563f8636ad7bcebf84047',
      'native_key' => 'magicpreview.preview_mode',
      'filename' => 'modSystemSetting/77003d51327d026d6a94383251cbba82.vehicle',
      'namespace' => 'magicpreview',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f13ca741373768543822dda2923dd56',
      'native_key' => 'magicpreview.panel_layout',
      'filename' => 'modSystemSetting/1e68c0b562d83c0f28ee39236d2a8d42.vehicle',
      'namespace' => 'magicpreview',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '609cc1a72b473e779273e9cd43b4a6f5',
      'native_key' => 'magicpreview.auto_refresh_interval',
      'filename' => 'modSystemSetting/70cc9a9841cd2ac78783d919c123d5d4.vehicle',
      'namespace' => 'magicpreview',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01d84196b2dd6228b39041cb128ffeb3',
      'native_key' => 'magicpreview.template_filter_mode',
      'filename' => 'modSystemSetting/59fb45132006dd9b6a4a802bd986936a.vehicle',
      'namespace' => 'magicpreview',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76acf76d6d22cf206fa7244aeba06c7c',
      'native_key' => 'magicpreview.template_filter_ids',
      'filename' => 'modSystemSetting/5c372fb8df8964209a84abcbc7923726.vehicle',
      'namespace' => 'magicpreview',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cc27b4dc78f0848e38c7cdc23293d13',
      'native_key' => 'magicpreview.draft_ttl',
      'filename' => 'modSystemSetting/f701be6b9c5842502bcc87a626516a3f.vehicle',
      'namespace' => 'magicpreview',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4c110ded2dc0b68036040ea6d43157f',
      'native_key' => 'magicpreview.share_link_ttl',
      'filename' => 'modSystemSetting/9d864e3d128f6c08ffb9542b9bd2d901.vehicle',
      'namespace' => 'magicpreview',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5d3ad1e0148dd1c512b7c2ae4d5d24f',
      'native_key' => 'magicpreview.click_to_field',
      'filename' => 'modSystemSetting/b7b8d1629730616d64c129e371bf4f70.vehicle',
      'namespace' => 'magicpreview',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75a202053c1279dc2ab510a14413a593',
      'native_key' => 'magicpreview.icon_save_draft',
      'filename' => 'modSystemSetting/6dd3ee43014c4d9606ce27f61b74a56e.vehicle',
      'namespace' => 'magicpreview',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c62e1a9377044b0e42695963945ac82c',
      'native_key' => 'magicpreview.icon_view',
      'filename' => 'modSystemSetting/d54aba26a6d3c1d8a1167b8350df4e07.vehicle',
      'namespace' => 'magicpreview',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '809771ea94800ba9736d92dc278e124f',
      'native_key' => 1,
      'filename' => 'modPlugin/c50fd3a830c6f914d23662df8bd05465.vehicle',
      'namespace' => 'magicpreview',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '057e908efa72b23de2e1c7a4b02d297d',
      'native_key' => 1,
      'filename' => 'modSnippet/6d19537b47b981a670dd1dfb31e886a7.vehicle',
      'namespace' => 'magicpreview',
    ),
  ),
);