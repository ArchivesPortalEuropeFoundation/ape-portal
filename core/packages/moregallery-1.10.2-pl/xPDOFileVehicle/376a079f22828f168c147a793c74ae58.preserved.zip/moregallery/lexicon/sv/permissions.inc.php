<?php

$_lang['moregallery.permission.view_gallery'] = 'Behörighet att visa galleriet i en resurs.';
$_lang['moregallery.permission.upload'] = 'Behörighet att ladda upp nya bilder i galleriet.';
$_lang['moregallery.permission.import'] = 'Rättighet att importera bilder till galleriet från mediebläddraren.';
$_lang['moregallery.permission.import_media'] = 'Behörighet att importera från Sterc\'s tillägg Media Manager.';
$_lang['moregallery.permission.video'] = 'Behörighet att lägga till videoklipp till galleriet.';
$_lang['moregallery.permission.resource_settings'] = 'Behörighet att ändra gallerirelaterade inställningar för resursen.';
$_lang['moregallery.permission.image_active'] = 'Behörighet att växla inställningen "aktiv" för en bild. Kräver behörigheten image_edit.';
$_lang['moregallery.permission.image_delete'] = 'Behörighet att ta bort en bild från ett galleri.';
$_lang['moregallery.permission.image_edit'] = 'Behörighet att redigera bildinformationen.';
$_lang['moregallery.permission.image_tags'] = 'Behörighet att hantera taggar tilldelade en bild. Kräver behörigheten image_edit.';
$_lang['moregallery.permission.image_tags_new'] = 'Behörighet att lägga till taggar som inte har använts tidigare. Kräver behörigheten image_tags.';
$_lang['moregallery.permission.image_crop_edit'] = 'Behörighet att redigera beskärningen för en bild. Kräver behörigheten image_edit.';
