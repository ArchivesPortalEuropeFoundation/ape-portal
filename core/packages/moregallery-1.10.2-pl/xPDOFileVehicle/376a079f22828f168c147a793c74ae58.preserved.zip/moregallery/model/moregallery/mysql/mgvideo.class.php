<?php
require_once (dirname(dirname(__FILE__)) . '/mgvideo.class.php');
class mgVideo_mysql extends mgVideo {}