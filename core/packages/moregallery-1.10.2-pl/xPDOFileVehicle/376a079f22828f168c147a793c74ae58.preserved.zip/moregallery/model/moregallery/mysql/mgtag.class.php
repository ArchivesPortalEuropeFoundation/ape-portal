<?php
require_once (dirname(dirname(__FILE__)) . '/mgtag.class.php');
class mgTag_mysql extends mgTag {}