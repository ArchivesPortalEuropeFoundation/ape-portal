<?php
$xpdo_meta_map['mgMediaManagerImage']= array (
  'package' => 'moregallery',
  'version' => '1.1',
  'extends' => 'mgImage',
  'inherit' => 'single',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
