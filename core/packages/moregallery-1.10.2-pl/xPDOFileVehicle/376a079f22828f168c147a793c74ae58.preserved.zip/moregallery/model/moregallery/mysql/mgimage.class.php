<?php
require_once (dirname(dirname(__FILE__)) . '/mgimage.class.php');
class mgImage_mysql extends mgImage {}