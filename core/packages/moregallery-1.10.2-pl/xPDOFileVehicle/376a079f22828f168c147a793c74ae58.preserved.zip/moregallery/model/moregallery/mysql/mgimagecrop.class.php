<?php
require_once (dirname(dirname(__FILE__)) . '/mgimagecrop.class.php');
class mgImageCrop_mysql extends mgImageCrop {}