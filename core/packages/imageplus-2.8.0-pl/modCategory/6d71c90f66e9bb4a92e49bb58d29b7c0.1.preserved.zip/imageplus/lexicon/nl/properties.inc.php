<?php

/** Snippet properties */
$_lang['imageplus.imageplus.tvname'] = 'Naam van de Image+ TV.';
$_lang['imageplus.imageplus.docid'] = 'Document waar de Image+ TV van geladen wordt.';
$_lang['imageplus.imageplus.type'] = 'Type van de snippet output. Dit kan een van de volgende waarden zijn: <i>check</i>, <i>tpl</i> of <i>thumb</i>.';
$_lang['imageplus.imageplus.options'] = 'Uitgebreide phpThumb opties voor de afbeelding.';
$_lang['imageplus.imageplus.tpl'] = 'Template chunk voor de snippet output.';
$_lang['imageplus.imageplus.value'] = 'Gebruik je eigen JSON gecodeerde waarde voor de snippet output. De properties <i>tvname</i> en <i>docid</i> worden genegeerd.';