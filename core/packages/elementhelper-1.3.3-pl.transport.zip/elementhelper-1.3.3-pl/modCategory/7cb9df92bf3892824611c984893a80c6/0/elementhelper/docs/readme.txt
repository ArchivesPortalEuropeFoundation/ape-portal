--------------------
Extra: Element Helper
--------------------
Version: 1.3.2
 
Element Helper is a MODx Revolution plugin for automatically creating elements from static files without the MODx manager.

For instructions on using ElementHelper please see - https://github.com/roryg/ElementHelper