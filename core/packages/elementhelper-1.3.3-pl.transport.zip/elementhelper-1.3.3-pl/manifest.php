<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Element Helper - A MODx plugin for automatically creating elements
from static files without the manager.

Copyright (C) 2013  Rory Gibson

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or 
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

http://www.gnu.org/licenses/',
    'readme' => '--------------------
Extra: Element Helper
--------------------
Version: 1.3.2
 
Element Helper is a MODx Revolution plugin for automatically creating elements from static files without the MODx manager.

For instructions on using ElementHelper please see - https://github.com/roryg/ElementHelper',
    'changelog' => 'Element Helper 1.3.3
====================================
- (JayCarney) Input properties fix
- (JayCarney) Added support for MIGX


Element Helper 1.3.2
====================================
- Fixed issue where deleting everything in the template_variables.json file prevented TVs from being removed in the manager.


Element Helper 1.3.1
====================================
- Fixed bug causing the Auto Remove Elements option to not work properly


Element Helper 1.3.0
====================================
- (exside) Added system setting elementhelper.usergroups to specify usergroups where ElementHelper should run, so page/manager are not slowed down by the plugin for users that cannot edit files in the target folders
- (exside) Added native modx caching to the plugin, so it only runs when a file in the target directories has changed, makes the plugin less obtrusive (by not checking all the files on every request) and makes it even possible to let it active on production sites (together with the usergroups feature)
- (exside) Updated translations (german/english)


Element Helper 1.2.2
====================================
- Fixed error where TVs were trying to assign templates that didn\'t exist.


Element Helper 1.2.1
====================================
- (exside) Fixed problems with media source 1 not pointing to base path
- (exside) Added system setting "elementhelper.source" to specify which media source should be used for the static files
- (exside) Added german translation
- (exside) Added setting to make the description key customizable
- Added setting for default element descriptions


Element Helper 1.2.0
====================================
- Fixed various errors and bugs
- Made cache clearing more specific to avoid clearing unnecessary parts of the cache
- Added element history so only elements created with ElementHelper will be deleted when their files have been removed


Element Helper 1.1.1
====================================
- Fixed bug causing TVs to lose their settings
- Stopped Plugins from being auto deleted


Element Helper 1.1.0
====================================
- Fixed warnings/errors when trying to access directories that don\'t exist.
- Added OnManagerPageInit event to the plugin so elements update when a manager page is loaded.
- Added the ability to use categories on TVs
- Added setting to allow elements to be deleted from the manager when their files are deleted.


Element Helper 1.0.0
====================================
- Initial release',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a59ab2a582b56996ace2a316a8fc3802',
      'native_key' => 'elementhelper',
      'filename' => 'modNamespace/ada1ba063cb2104199d3a01c98dc75bc.vehicle',
      'namespace' => 'elementhelper',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ffd4a10a12c4d42f08ac3003fa5045b4',
      'native_key' => 1,
      'filename' => 'modCategory/7cb9df92bf3892824611c984893a80c6.vehicle',
      'namespace' => 'elementhelper',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49bf4db5c5d0541b42f9c5210bd89bb8',
      'native_key' => 'elementhelper.chunk_path',
      'filename' => 'modSystemSetting/f1734625e3e67460245027a4dc25edd2.vehicle',
      'namespace' => 'elementhelper',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9df223de40af4db1fab84bfa4c6abd',
      'native_key' => 'elementhelper.template_path',
      'filename' => 'modSystemSetting/fc4e38c8aa4a3055ef6f121d2b7d0bc5.vehicle',
      'namespace' => 'elementhelper',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6edf88e9895325e14676d483977af894',
      'native_key' => 'elementhelper.plugin_path',
      'filename' => 'modSystemSetting/16a12071421a979d812c3687908697cb.vehicle',
      'namespace' => 'elementhelper',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87b8dcfe66bb6c8b5f2836ad4b2e6c4b',
      'native_key' => 'elementhelper.snippet_path',
      'filename' => 'modSystemSetting/88866e29e936a467bf270a684ee55b25.vehicle',
      'namespace' => 'elementhelper',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1fcf38dde773fc34a93c2c17f525f11',
      'native_key' => 'elementhelper.tv_json_path',
      'filename' => 'modSystemSetting/52f85f3076d31d185fb846efc310ebd4.vehicle',
      'namespace' => 'elementhelper',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8f84d19022160d9e055db44d19183a8',
      'native_key' => 'elementhelper.tv_access_control',
      'filename' => 'modSystemSetting/ebb16742966ad5ed9d313171267b1cae.vehicle',
      'namespace' => 'elementhelper',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37d39b8a105eeb65417a161b6084ecb7',
      'native_key' => 'elementhelper.auto_remove_elements',
      'filename' => 'modSystemSetting/eee052a5e7e7f9122797bf62a562af09.vehicle',
      'namespace' => 'elementhelper',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6670a2ab24dac7c4c1613cc299f0abf0',
      'native_key' => 'elementhelper.element_history',
      'filename' => 'modSystemSetting/a65da6dcdb1c7964ab402836326e349b.vehicle',
      'namespace' => 'elementhelper',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d7895d043e7672f6e9659dd8d1e0bbd',
      'native_key' => 'elementhelper.source',
      'filename' => 'modSystemSetting/bde6e861eb8c2c383a3bfadebb5c9d5d.vehicle',
      'namespace' => 'elementhelper',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2d7fdfbd9b87562c87e5bb675f1b4e7',
      'native_key' => 'elementhelper.descriptionkey',
      'filename' => 'modSystemSetting/12611ecb2081c2601660d3b5272dddbb.vehicle',
      'namespace' => 'elementhelper',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48aced59a7f909f5627be80318af65f6',
      'native_key' => 'elementhelper.default_description',
      'filename' => 'modSystemSetting/073c872c0b13a1f1c174e5836815a918.vehicle',
      'namespace' => 'elementhelper',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7f445f86af3337abeaed4d3bb18fa5e',
      'native_key' => 'elementhelper.usergroups',
      'filename' => 'modSystemSetting/131abd804bfd97d161135003e00ce2d8.vehicle',
      'namespace' => 'elementhelper',
    ),
  ),
);