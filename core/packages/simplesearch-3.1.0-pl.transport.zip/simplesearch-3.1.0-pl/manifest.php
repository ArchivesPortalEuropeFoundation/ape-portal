<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MODX SimpleSearch
![SimpleSearch version](https://img.shields.io/badge/version-3.0.0-blue.svg) ![MODX version requirements](https://img.shields.io/badge/modx%20version%20requirement-3.0%2B-brightgreen.svg)

## Installation
Simply install it through the top menu ```Extras > Installer``` and search for ```SimpleSearch```. Install it from there. After installing it, it is recommended to clear your MODX cache, through the top menu ```Manage > Clear Cache```.

## Upgrade risks
This is currently alpha software and is only compatible with MODX 3.x and higher. This has been tested on basic search queries, but you may encounter problems with more advanced setups. 

## Autosuggest
A processor has been provided for retrieving a list of search suggestions based on a Template Variable containing a comma delimited list of search terms. 
You can configure the TV to use by setting `simplesearch.autosuggest_tv`, which can either be the TV name or id.

You can use the example (requires jQuery) code below for retrieving a list of search suggestions.

```javascript
$(\'.simplesearch-search-form input[type="text"]\').on(\'keyup\', function () {
    var value = $(this).val();

    $.ajax({
        url         : \'/assets/components/simplesearch/connector.php?action=web/autosuggestions&search=\' + value,
        dataType    : \'JSON\',
        complete    : function (result) {
            console.log(result.results);
        }
    });
});
```

## Bugs and feature requests
We value your feedback, feature requests and bug reports. Please issue them on [Github](https://github.com/modxcms/SimpleSearch/issues/new)..

Need help? [Contact MODX Help Desk](mailto:help@modx.com)
',
    'changelog' => 'Changelog for SimpleSearch.

SimpleSearch 3.1.0
========================================================================
- Fix toPlaceholder property
- Fix fatal error when content field is NULL
- Fix property "exclude"
- Limit result with SQL if property "sortBy" is used
- Check if exact text is set to prevent breaking of results.
- Add the option to exclude/include results based on templates
- Fix "ids" property, if it contains IDs from different contexts
- Automatically remove outdated SimpleSearchIndexer plugin if it exists

SimpleSearch 3.0.0
========================================================================
- Added support for MODX3

SimpleSearch 2.1.2
========================================================================
- Show facet results when default has none.
- Have all placeholders in no result page
- Fix pagination for pageLimit & facet search

SimpleSearch 2.1.1
========================================================================
- Fix includeTVList bug to show normal search results as well.

SimpleSearch 2.1.0
========================================================================
- Added pdoParser support
- Fix XSS security issue

SimpleSearch 2.0.1
========================================================================
- Fixed so that includedTVs can also be boosted PR #1
- Fixed condition for leftJoin of query to only join includeTVList TemplateVars when property is set. PR #5. Thanks to travisbotello
- Fixed issue with currentPageTpl. PR #6. Thanks to travisbotello.

SimpleSearch 2.0.0
========================================================================
- Removed elasticsearch and solr driver
- Renamed namespace sisea to simplesearch
- Fixed issue where boosting would only be applied to paginated results
- Added processor for returning a search autosuggest list

SimpleSearch 1.9.2
========================================================================
- Generate extract for whole search string, not just for last part
- Added option to add search term into the link
- Fixed generating extracts

SimpleSearch 1.9.1
========================================================================
- Fixed indexing resource when it\'s not published or deleted
- Fixed error with redeclared function in plugin
- Added includeTVList parameter

SimpleSearch 1.9.0
========================================================================
- Added extractSource parameter - names the field for the extract, or a snippet to run (which is passed the resource array as properties)

SimpleSearch 1.8.1
========================================================================
- Added snippet for definition of ElasticSearch index (duplicate it and remove the _default from name to prevent recreating after update)

SimpleSearch 1.8.0
========================================================================
- Added support to ElasticSearch driver for using search fields
- Added support to ElasticSearch driver for boosting results by a field value
- Updated Elastica to v0.90.7.0
- [#84] Czech localization
- [#78] Japanese localization
- [#77] Enable $tvPrefix to prefix TV placeholders
- [#2] Do not search TV values if includeTVs != 1 (modxcms/SimpleSearch#2)
- [#1] Fixed SQL for "exclude" parameter (modxcms/SimpleSearch#1)
- Added driver for ElasticSearch
- Added support to ElasticSearch driver for using search fields
- Added support to ElasticSearch driver for boosting results by a field value
- Updated Elastica to v0.90.7.0
- Added outputSeparator option

SimpleSearch 1.7.0
========================================================================
- Added driver for ElasticSearch

SimpleSearch 1.6.1
========================================================================
- [#69] Apply additional guard against injection of modx tags

SimpleSearch 1.6.0
========================================================================
- [#65] Fix issue with multiple search terms highlighting
- [#67] Fix issue with quotations breaking forms in SimpleSearchForm snippet
- [#64] Improved pagination links, added pageLimit and optional extra tpls

SimpleSearch 1.5.2
========================================================================
- Fix invalid mb_strlen call when should be strlen
- [#60] Fix issue with search highlighting

SimpleSearch 1.5.1
========================================================================
- [#55] Fix issue with offsets in multibyte, one-character searches
- [#59] Fix issue with broken links on pagination

SimpleSearch 1.5.0
========================================================================
- [#36] Fix issue where whereGroup is not incr when using useAllWords
- Allow file-based chunks in all tpl chunks
- [#53] Ensure list permission is checked on loading of resources
- [#56] Fix issue with forward slashes in searches

SimpleSearch 1.4.1
========================================================================
- Ensure Solr search gets TVs indexed

SimpleSearch 1.4.0
========================================================================
- Improved TV indexing for Solr-based searches, all TVs are now pre-processed and included during index
- Fixed bug with processTVs in basic search
- [#49] Add sortBy and sortDir properties for sorting of results
- [#48] Fix issue with internationalization of no results message
- [#50] Fix issue with pagination and searches with spaces
- Added Solr search implementation, split up search into driver-specific classes
- [#37] Fix charset in German translation
- [#46] Add tpl for no results message, in property noResultsTpl

SimpleSearch 1.3.0
========================================================================
- Fix bug in simplesearchform.snippet where spaces were being removed from searchValue
- Fix SqlSrv query issues
- Add sisea.facet placeholder for results page, and \'search\' parameter to be sent into posthooks
- Add faceted search ability through postHooks
- Add facetLimit to limit # of non-active facet results that return on main results page

SimpleSearch 1.2.0
========================================================================
- Fixed bug with pagination
- Fixed bug with searchScore sorting
- Fixed bug with progressive highlighting class names
- Added \'alias\' to default docFields
- Added fieldPotency property to allow certain fields higher search scores for the same match
- Added result sorting (by searchScores)

SimpleSearch 1.1.2
========================================================================
- Added the urlScheme parameter which allows you to control the URL scheme used
  for the pagination links.
- Made the result extracts to never break words. This means that the extract
  limit is a soft limit now, and results look much nicer.
- Added the query placeholder to the containerTpl chunk.
- Fixed the default value of the landing parameter for the SimpleSearchForm
  snippet.
- Fixed an URL decoding bug.
- Removed defaults from the provided chunk templates, as they duplicate code
  from the snippets.
- Made minor performance improvements.

SimpleSearch 1.1.1
========================================================================
- Fixed bug in snippet with wrong reference to $modx var
- Added idx placeholder
- Added German translation
- Added andTerm (true/false) - Whether or not to add a logical AND between words in search term.
- Added matchWildcard (behavior depending on query type and limitations)
- Added docFields which is a list of fields to search on the Resource.

SimpleSearch 1.1.0
========================================================================
- Added ability to use TVs in placeholders
- Added ability to exclude resources
- Added missing f parameter if ids was empty
- Added longtitle to partial search style
- Fixed XHTML get/post in form tpl issue

SimpleSearch 1.0.0
========================================================================
- Now searches unprocessed TVs
- Added &customPackages property for searching custom packages
- Added fix for GET searches
- Added sisea.query and sisea.count global placeholders for search count/query string
- Fixed bug with multibyte chars
- Fixed bug with contexts param that was leaving search results empty
- Fixed bug with separators doubling
- Fixed bug with perPage not being respected due to shared object instance
- Added Russian translation
- Prepared for initial 1.0-beta release
- Adjusted toPlaceholder behavior through output() method
- Created build script
- Initial commit
',
    'requires' => 
    array (
      'modx' => '>=3.0.0-alpha',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '133862996a2d635adbeef7d7a976f39d',
      'native_key' => 'simplesearch',
      'filename' => 'MODX/Revolution/modNamespace/b6bf931ebb5c89452f5437736a920d13.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38d6b90a82ea8a71a144728bfbf0756e',
      'native_key' => 'simplesearch.driver_class',
      'filename' => 'MODX/Revolution/modSystemSetting/fd00409ab9018cace4ce47f49c3e060b.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8969e44b3c5734c8e07ae183347c575c',
      'native_key' => 'simplesearch.autosuggest_tv',
      'filename' => 'MODX/Revolution/modSystemSetting/5b75b210cd39bea07db4c993ce10ca67.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '973e97e73ce6385bbee22a417fa1cac8',
      'native_key' => '973e97e73ce6385bbee22a417fa1cac8',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/4d0ffa10baa39a056db9d643997b40b0.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '928b7b94e66b4b1b1aa60d6a12a049b5',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/3109076de2358a2cf1e55db8c2353fbd.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '8f727a00bf97aa59cd08895cb82f10f4',
      'native_key' => '8f727a00bf97aa59cd08895cb82f10f4',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/c07635efec85f23ae0b4e7c479c7ad56.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '888a7ac5c076c323373b89254d3c6234',
      'native_key' => '888a7ac5c076c323373b89254d3c6234',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/15b8585a08552c62227593d8d72c1055.vehicle',
    ),
  ),
);